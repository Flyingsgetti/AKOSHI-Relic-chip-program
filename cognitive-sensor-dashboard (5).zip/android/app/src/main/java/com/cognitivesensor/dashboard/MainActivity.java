package com.cognitivesensor.dashboard;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
