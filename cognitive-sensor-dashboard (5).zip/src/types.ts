export interface SensorPoint {
  x: number;
  y: number;
  z: number;
}

export interface SensorData {
  gyro: SensorPoint;
  accel: SensorPoint;
  micLeft: number;
  micRight: number;
  heading: number;
}

export interface SettingsConfig {
  processingSpeed: number;
  neuralDensity: number;
  simulationLag: number;
  learningRate: number;
  dreamIntensity: number;
  consciousThreshold: number;
  emotionalWeightRate: number;
  memoryRetention: number;
  
  // Visual & Sensor Settings
  visualMode: 'camera' | 'echolocation';
  flashlightActive: boolean;
  cameraContrast: number;
  cameraSepia: number;
  cameraHue: number;
  cameraBrightness: number;
  
  echoSensitivity: number;
  echoRange: number;

  // New Hardware/Schedule
  dreamScheduleHour: number; // 0-23
  cffRate: number; // Hz
  selectedCameraId: string;
  selectedCamera2Id: string;
  enableCamera2: boolean;
  
  // Media files
  bgmFile: string | null;
  sfxFile: string | null;

  // Hardware Allocations
  cpuAllocationCore: number;
  cpuAllocationVision: number;
  gpuAllocation: number;
  ramAllocation: number;

  // Peripheral Vision emulation
  peripheralBlur: number;       // Blur radius at edges (0-30px)
  peripheralPixelation: number; // Pixelation pattern density & visibility at edges (0-20)

  // Advanced Cognitive
  mimicryRate: number;
  linguisticPlasticity: number;
  curiosityIndex: number;
  matchGridToNeurons: boolean;
  maxStoragePool: number; // in MB
  memoriesPerSecond: number; // memories recorded per second
}

export interface Memory {
  id: string;
  hash: string;
  timestamp: number;
  type: 'conscious' | 'subconscious' | 'dream';
  imageUrl?: string;
  sensors: SensorData;
  eventLog: string;
  emotion: 'happy' | 'sad' | 'angry' | 'neutral';
  storageSize: number; // in KB
}

export interface MemoryPoint {
  id: string;
  timestamp: number;
  imageUrl: string;
}
