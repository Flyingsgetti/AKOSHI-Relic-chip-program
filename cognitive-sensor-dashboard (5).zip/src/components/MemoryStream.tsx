import { Memory } from "../types";
import { Camera, AudioWaveform, Activity } from "lucide-react";

interface Props {
  memories: Memory[];
  onOpenGallery: () => void;
}

export function MemoryStream({ memories, onOpenGallery }: Props) {
  return (
    <div className="w-full max-w-4xl mt-4 bg-cyber-black/80 border border-cyber-cyan/30 flex flex-col backdrop-blur-md h-[300px]">
      <div className="flex justify-between items-center bg-cyber-cyan/10 p-2 border-b border-cyber-cyan/30">
        <h2 className="font-orbitron font-bold text-cyber-cyan text-sm tracking-widest pl-2">
          MEMORY STREAM FEED
        </h2>
        <button 
          onClick={onOpenGallery}
          className="text-cyber-yellow hover:bg-cyber-yellow/20 px-3 py-1 font-mono text-xs border border-cyber-yellow/50 transition-all flex items-center gap-2"
        >
          <Camera size={14} />
          OPEN GALLERY
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-3 custom-scrollbar flex flex-col-reverse">
        {memories.length === 0 ? (
          <div className="text-cyber-cyan/50 text-center font-mono text-xs mt-10">NO MEMORIES RECORDED</div>
        ) : (
          memories.map((mem) => (
            <div 
              key={mem.id} 
              className={`p-3 border flex gap-4 ${mem.type === 'conscious' ? 'border-cyber-cyan/40 bg-cyber-cyan/5' : mem.type === 'dream' ? 'border-cyber-yellow/40 bg-cyber-yellow/5' : 'border-cyber-red/40 bg-cyber-red/5'}`}
            >
              {mem.imageUrl ? (
                <div className="w-16 h-16 shrink-0 border border-cyber-cyan/30 p-1 relative">
                  <div className="absolute inset-0 bg-cyber-cyan/20 absolute z-10 filter mix-blend-color" />
                  <img src={mem.imageUrl} className="w-full h-full object-cover filter contrast-125 saturate-50 sepia-[.4] hue-rotate-180" alt="Memory capture" />
                </div>
              ) : (
                <div className="w-16 h-16 shrink-0 border border-cyber-cyan/30 flex items-center justify-center bg-black/50 overflow-hidden">
                   <div className="text-[8px] font-mono text-cyber-cyan/30 text-center leading-tight">NO<br/>IMG<br/>DATA</div>
                </div>
              )}
              <div className="font-mono text-xs flex-1 text-cyber-cyan flex flex-col gap-1">
                <div className="flex justify-between border-b border-cyber-cyan/20 pb-1 mb-1">
                  <span className="text-cyber-yellow">{mem.type.toUpperCase()} THREAD</span>
                  <span className="opacity-50">{new Date(mem.timestamp).toISOString().split('T')[1].slice(0,-1)}</span>
                </div>
                <div className="text-white/80">{mem.eventLog}</div>
                <div className="flex gap-4 mt-2 text-[10px] opacity-70">
                   <span className="flex items-center gap-1"><Activity size={10} /> X:{mem.sensors.accel.x.toFixed(1)} Y:{mem.sensors.accel.y.toFixed(1)} Z:{mem.sensors.accel.z.toFixed(1)}</span>
                   <span className="flex items-center gap-1"><AudioWaveform size={10} /> L:{mem.sensors.micLeft.toFixed(0)} R:{mem.sensors.micRight.toFixed(0)}</span>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
