import { Memory } from "../types";
import { X, Activity, Droplet } from "lucide-react";

interface Props {
  memories: Memory[];
  onClose: () => void;
  onInjectMemory: () => void;
}

export function GalleryModal({ memories, onClose, onInjectMemory }: Props) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 sm:p-8">
      <div className="w-full max-w-6xl h-full max-h-[80vh] border border-cyber-yellow/40 bg-cyber-black flex flex-col">
        
        {/* Header */}
        <div className="flex justify-between items-center p-3 border-b border-cyber-yellow/40 bg-cyber-yellow/10">
          <div className="flex items-center gap-4">
             <h2 className="font-orbitron font-bold text-cyber-yellow tracking-widest pl-2">MEMORY GALLERY DATABASE</h2>
             <button 
               onClick={onInjectMemory}
               className="border border-cyber-cyan/50 text-cyber-cyan text-[10px] px-2 py-1 flex items-center gap-1 hover:bg-cyber-cyan/20 transition-all font-mono"
             >
               <Droplet size={12} /> INJECT MEMORY
             </button>
          </div>
          <button onClick={onClose} className="p-1 hover:bg-cyber-red/20 text-cyber-yellow hover:text-cyber-red transition-colors">
            <X size={20} />
          </button>
        </div>

        {/* Grid View */}
        <div className="flex-1 overflow-y-auto p-4 md:p-6 grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4 custom-scrollbar">
          {memories.filter(m => m.imageUrl).length === 0 ? (
             <div className="col-span-full h-full flex items-center justify-center font-mono text-cyber-cyan/50">NO VISUAL RECORDS LOCATED IN DATABASE</div>
          ) : null}

          {memories.filter(m => m.imageUrl).map(mem => (
            <div key={mem.id} className="group relative border border-cyber-cyan/30 bg-black aspect-square overflow-hidden flex flex-col">
              <div className="relative flex-1 overflow-hidden bg-black/40">
                <div className="absolute inset-0 bg-cyber-red/10 group-hover:bg-cyber-cyan/20 transition-colors z-30 mix-blend-color pointer-events-none" />
                {mem.type === 'subconscious' ? (
                   // Subconscious is zoomed-in/partially remembered fragment
                   <img 
                     src={mem.imageUrl} 
                     className="absolute w-[250%] h-[250%] max-w-none object-cover filter contrast-125 saturate-50 sepia-[.4] hue-rotate-180 brightness-75 group-hover:brightness-100 transition-all" 
                     style={{ top: '-40%', left: '-30%' }}
                     alt="Subconscious fragment" 
                   />
                ) : mem.type === 'dream' ? (
                   // Dream is composite shifts
                   <>
                     <img 
                       src={mem.imageUrl} 
                       className="absolute w-full h-full object-cover opacity-50 filter contrast-125 saturate-150 brightness-75 group-hover:brightness-100 transition-all" 
                       alt="Dream backing" 
                     />
                     <img 
                       src={mem.imageUrl} 
                       className="absolute w-[180%] h-[180%] max-w-none object-cover opacity-60 mix-blend-screen scale-75 rotate-12" 
                       style={{ top: '-10%', left: '-10%', filter: 'hue-rotate(90deg)' }} 
                       alt="Dream shift overlay" 
                     />
                   </>
                ) : (
                   // Conscious remembers the whole image
                   <img 
                     src={mem.imageUrl} 
                     className="w-full h-full object-cover filter contrast-125 saturate-50 sepia-[.4] hue-rotate-180 brightness-75 group-hover:brightness-100 transition-all" 
                     alt="Conscious record" 
                   />
                )}
                
                {/* Overlay Metadata */}
                <div className="absolute bottom-0 left-0 right-0 p-1.5 bg-gradient-to-t from-black/90 to-transparent z-40 flex flex-col gap-0.5">
                   <div className="flex justify-between items-center font-mono text-[9px] text-cyber-cyan">
                     <span className={mem.type === 'dream' ? 'text-cyber-yellow' : 'text-cyber-cyan'}>{mem.type.toUpperCase()}</span>
                     <span>{new Date(mem.timestamp).toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' })}</span>
                   </div>
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>
    </div>
  );
}
