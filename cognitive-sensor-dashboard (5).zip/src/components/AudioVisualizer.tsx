import { useRef, useEffect, useState } from "react";

interface Props {
  channel: "Left" | "Right";
}

export function AudioVisualizer({ channel }: Props) {
  const [level, setLevel] = useState(0);

  // Fake audio visualizer effect
  useEffect(() => {
    const interval = setInterval(() => {
      setLevel(Math.random() * 100);
    }, 100);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="p-2 border border-cyber-red/50 bg-cyber-black/80 backdrop-blur-md flex flex-col gap-1 w-full max-w-[150px]">
      <span className="font-orbitron w-full text-center text-xs text-cyber-yellow">{channel} MIC</span>
      <div className="h-2 w-full bg-cyber-darkred overflow-hidden flex">
         <div 
           className="h-full bg-cyber-cyan transition-all duration-75"
           style={{ width: `${level}%` }}
         />
      </div>
    </div>
  );
}
