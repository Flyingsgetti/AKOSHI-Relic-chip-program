import { SensorPoint } from "../types";

export function AxisIndicator({ gyro, accel }: { gyro: SensorPoint, accel: SensorPoint }) {
  // Translate the "gyro" state (which is currently used as rotation degrees) into CSS transforms
  const transform = `rotateX(${gyro.x}deg) rotateY(${gyro.y}deg) rotateZ(${gyro.z}deg)`;

  // Normalize acceleration for illumination
  // Accel comes in m/s^2. Max realistic acceleration for full brightness might be ~20 m/s^2
  const maxAccel = 20;
  
  const getOp = (val: number) => {
    const norm = Math.min(Math.abs(val) / maxAccel, 1);
    // base opacity 0.5, plus variation up to 0.5 to make it hit 1.0
    return 0.5 + norm * 0.5;
  };

  const getShadow = (val: number, color: string) => {
    const norm = Math.min(Math.abs(val) / maxAccel, 1);
    const blur = norm * 20 + 2;
    const spread = norm * 10;
    return norm > 0.1 ? `0 0 ${blur}px ${spread}px ${color}` : "none";
  };

  const xOp = getOp(accel.x);
  const yOp = getOp(accel.y);
  const zOp = getOp(accel.z);
  
  const xShad = getShadow(accel.x, "rgba(220, 38, 38, 0.8)"); // red
  const yShad = getShadow(accel.y, "rgba(34, 197, 94, 0.8)"); // green
  const zShad = getShadow(accel.z, "rgba(37, 99, 235, 0.8)"); // blue

  return (
    <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-0 pointer-events-none opacity-80">
      <div 
        className="relative w-64 h-64 flex items-center justify-center"
        style={{ perspective: '1000px' }}
      >
        <div 
          className="absolute w-full h-full transition-transform duration-100 ease-linear"
          style={{ transform, transformStyle: 'preserve-3d' }}
        >
          {/* X Axis - Red */}
          <div 
            className="absolute top-1/2 left-1/2 w-32 h-[3px] bg-red-600 -translate-y-1/2 origin-left border border-black/50 pointer-events-none transition-all duration-75"
            style={{ opacity: xOp, boxShadow: xShad }}
          >
            {/* Arrow Head */}
            <div className="absolute right-0 top-1/2 -translate-y-1/2 w-0 h-0 border-t-4 border-b-4 border-l-8 border-transparent border-l-red-600 translate-x-full"></div>
            <span className="absolute right-2 -top-6 font-orbitron text-xs text-red-500 font-bold block" style={{transform: `rotateZ(${-gyro.z}deg) rotateY(${-gyro.y}deg) rotateX(${-gyro.x}deg)`, opacity: xOp > 0.6 ? 1 : 0.7 }}>x axis</span>
          </div>

          {/* Y Axis - Green */}
          <div 
            className="absolute top-1/2 left-1/2 h-32 w-[3px] bg-green-500 -translate-x-1/2 origin-bottom -translate-y-full border border-black/50 pointer-events-none transition-all duration-75"
            style={{ opacity: yOp, boxShadow: yShad }}
          >
            {/* Arrow Head */}
            <div className="absolute left-1/2 top-0 -translate-x-1/2 w-0 h-0 border-l-4 border-r-4 border-b-8 border-transparent border-b-green-500 -translate-y-full"></div>
            <span className="absolute top-1 -left-12 w-24 text-center font-orbitron text-xs text-green-400 font-bold block" style={{transform: `rotateZ(${-gyro.z}deg) rotateY(${-gyro.y}deg) rotateX(${-gyro.x}deg)`, opacity: yOp > 0.6 ? 1 : 0.7 }}>y axis</span>
          </div>

          {/* Z Axis - Blue (Using 3D rotation) */}
          <div 
            className="absolute top-1/2 left-1/2 w-[3px] h-32 bg-blue-600 -translate-x-1/2 origin-top border border-black/50 pointer-events-none transition-all duration-75" 
            style={{ transform: 'rotateX(-90deg)', opacity: zOp, boxShadow: zShad }}
          >
             {/* Arrow Head */}
             <div className="absolute left-1/2 bottom-0 -translate-x-1/2 w-0 h-0 border-l-4 border-r-4 border-t-8 border-transparent border-t-blue-600 translate-y-full"></div>
             <span className="absolute bottom-2 -left-12 w-24 text-center font-orbitron text-xs text-blue-400 font-bold block" style={{transform: `rotateX(90deg) rotateZ(${-gyro.z}deg) rotateY(${-gyro.y}deg) rotateX(${-gyro.x}deg)`, opacity: zOp > 0.6 ? 1 : 0.7 }}>z axis</span>
          </div>
          
          {/* Center Point */}
          <div className="absolute top-1/2 left-1/2 w-4 h-4 bg-black border-2 border-white/50 rounded-full -translate-x-1/2 -translate-y-1/2 shadow-lg" />
        </div>
      </div>
    </div>
  );
}
