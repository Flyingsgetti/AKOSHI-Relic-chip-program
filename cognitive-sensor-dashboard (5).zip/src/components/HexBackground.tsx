import { useEffect, useRef } from 'react';

interface HexBlock {
  x: number;
  y: number;
  lines: string[];
  type: 'hex' | 'bin';
  speed: number;
  opacity: number;
}

export function HexBackground({ speed = 1, lag = 0, cffRate = 60 }: { speed?: number, lag?: number, cffRate?: number }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let blocks: HexBlock[] = [];
    const fontSize = 10;
    const lineHeight = 12;
    
    const hexChars = "0123456789ABCDEF".split("");
    const binChars = "01".split("");

    const generateBlock = (canvasWidth: number, canvasHeight: number, isBottomLeftBlock = false): HexBlock => {
      const type = Math.random() > 0.5 || isBottomLeftBlock ? 'hex' : 'bin';
      const cols = isBottomLeftBlock ? 45 : Math.floor(Math.random() * 15) + 5;
      const rows = isBottomLeftBlock ? 15 : Math.floor(Math.random() * 25) + 10;
      const sourceChars = type === 'hex' ? hexChars : binChars;
      
      const lines = [];
      for (let i = 0; i < rows; i++) {
        let lineStr = "";
        for (let j = 0; j < cols; j++) {
           lineStr += sourceChars[Math.floor(Math.random() * sourceChars.length)] + (type === 'hex' ? " " : "");
        }
        lines.push(lineStr);
      }
      
      let x = 0;
      let y = 0;
      
      if (isBottomLeftBlock) {
        x = 20;
        y = canvasHeight - (rows * lineHeight) - 20;
      } else {
        // distribute to the edges mostly
        x = Math.random() > 0.5 ? Math.random() * 100 : canvasWidth - 200 - Math.random() * 100;
        y = Math.random() * canvasHeight;
      }

      return {
        x,
        y,
        type,
        lines,
        speed: isBottomLeftBlock ? 0 : (Math.random() * 0.5 + 0.1),
        opacity: isBottomLeftBlock ? 0.3 : (Math.random() * 0.3 + 0.1)
      };
    };

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
      blocks = [];
      blocks.push(generateBlock(canvas.width, canvas.height, true)); // Big bottom-left block
      for (let i = 0; i < 6; i++) {
        blocks.push(generateBlock(canvas.width, canvas.height, false));
      }
    };

    window.addEventListener('resize', resize);
    resize();

    let lastTime = 0;

    const draw = (time: number) => {
      // Simulate lag by skipping frames
      if (lag > 0 && Math.random() < lag) {
        animationFrameId = requestAnimationFrame(draw);
        return;
      }
      
      const deltaTime = time - lastTime;
      const targetInterval = 1000 / cffRate;
      
      if (deltaTime < targetInterval) {
        animationFrameId = requestAnimationFrame(draw);
        return;
      }
      lastTime = time - (deltaTime % targetInterval); // adjust lastTime to maintain precise intervals

      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.font = `${fontSize}px "Orbitron"`;

      for (let i = 0; i < blocks.length; i++) {
        const block = blocks[i];
        
        ctx.fillStyle = `rgba(197, 0, 60, ${block.opacity})`; // #c5003c lighter cyber-red

        // Periodically mutate characters
        if (Math.random() > 0.8) {
           const rowIdx = Math.floor(Math.random() * block.lines.length);
           const chars = block.type === 'hex' ? hexChars : binChars;
           const newChar = chars[Math.floor(Math.random() * chars.length)];
           const cIdx = Math.floor(Math.random() * (block.lines[rowIdx].length / (block.type === 'hex' ? 2 : 1))) * (block.type === 'hex' ? 2 : 1);
           const arr = block.lines[rowIdx].split('');
           arr[cIdx] = newChar;
           block.lines[rowIdx] = arr.join('');
        }

        block.lines.forEach((line, lineIndex) => {
          ctx.fillText(line, block.x, block.y + (lineIndex * lineHeight));
        });

        if (block.speed > 0) {
           block.y -= block.speed;
           if (block.y + (block.lines.length * lineHeight) < 0) {
              blocks[i] = generateBlock(canvas.width, canvas.height, false);
              blocks[i].y = canvas.height;
           }
        }
      }

      animationFrameId = requestAnimationFrame(draw);
    };

    animationFrameId = requestAnimationFrame(draw);

    return () => {
      window.removeEventListener('resize', resize);
      cancelAnimationFrame(animationFrameId);
    };
  }, [speed, lag]);

  return (
    <canvas 
      ref={canvasRef} 
      className="absolute inset-x-0 top-0 z-0 h-full w-full pointer-events-none mix-blend-screen"
    />
  );
}
