import { Settings, Image as ImageIcon, Play, Square, Moon, Compass } from "lucide-react";

interface Props {
  isRecording: boolean;
  onToggleRecord: () => void;
  dreamMode: boolean;
  onToggleDream: () => void;
  onOpenSettings: () => void;
  onOpenGallery: () => void;
  ping: number;
  onResetAxis: () => void;
}

export function ControlPanel({ isRecording, onToggleRecord, dreamMode, onToggleDream, onOpenSettings, onOpenGallery, ping, onResetAxis }: Props) {
  return (
    <div className="flex flex-col gap-3 font-mono text-[10px]">
        {/* Record Button */}
        <button 
          onClick={onToggleRecord}
          disabled={dreamMode}
          className={`flex items-center justify-between gap-4 px-3 py-1 border transition-all disabled:opacity-50 disabled:cursor-not-allowed glitch-hardware ${
            isRecording 
              ? 'border-cyber-cyan text-cyber-cyan bg-cyber-cyan/10' 
              : 'border-cyber-cyan/50 text-cyber-cyan/70 hover:bg-cyber-cyan/10 hover:border-cyber-cyan'
          }`}
        >
          <div className="flex items-center gap-2 tracking-widest">
             {isRecording ? <Square size={12} className="fill-current text-cyber-red" /> : <Play size={12} className="text-cyber-cyan" />}
             RECORD
          </div>
          <div className={`w-1.5 h-1.5 rounded-full ${isRecording ? 'bg-cyber-red animate-pulse' : 'bg-transparent'}`} />
        </button>

        {/* Dream Button */}
        <button 
          onClick={onToggleDream}
          className={`flex items-center justify-between gap-4 px-3 py-1 border transition-all glitch-hardware ${
            dreamMode 
              ? 'border-cyber-yellow text-cyber-yellow bg-cyber-yellow/10' 
              : 'border-cyber-cyan/50 text-cyber-cyan/70 tracking-widest hover:bg-cyber-yellow/10'
          }`}
        >
          <div className="flex items-center gap-2 tracking-widest font-orbitron">
             <Moon size={12} className={dreamMode ? "fill-current text-cyber-yellow animate-bounce" : ""} />
             {dreamMode ? "DREAMING..." : "DREAM START"}
          </div>
          <div className={`w-1.5 h-1.5 rounded-full ${dreamMode ? 'bg-cyber-yellow animate-pulse' : 'bg-transparent'}`} />
        </button>
        
        <div className="flex gap-2 w-full mt-2">
            <button 
              onClick={onOpenSettings}
              className="px-2 py-1 border border-cyber-cyan/30 text-cyber-cyan/70 hover:bg-cyber-cyan/20 hover:text-cyber-cyan hover:border-cyber-cyan transition-all flex items-center justify-center flex-1 gap-2 glitch-hardware"
            >
              <Settings size={12} /> SETUP
            </button>
            <div className="flex border border-cyber-cyan/30 items-center justify-center flex-1 px-2 text-cyber-cyan/50">
               {ping.toFixed(0)}<sub>ms</sub>
            </div>
        </div>

        {/* Calibrate Axis Button */}
        <button 
          onClick={onResetAxis}
          className="w-full px-3 py-1.5 mt-1 border border-[#55ead4]/50 text-[#55ead4] hover:bg-[#55ead4]/15 hover:border-[#55ead4] active:bg-[#55ead4]/25 transition-all flex items-center justify-center gap-2 font-orbitron font-semibold tracking-wider glitch-hardware"
        >
          <Compass size={12} className="text-[#55ead4]" />
          CALIBRATE AXIS
        </button>
    </div>
  );
}
