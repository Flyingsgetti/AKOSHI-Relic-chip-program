import { SettingsConfig } from "../types";
import { X, Sliders, Camera, Cpu } from "lucide-react";
import { useState, useEffect } from "react";

interface Props {
  settings: SettingsConfig;
  onUpdate: (key: keyof SettingsConfig, value: any) => void;
  onClose: () => void;
}

export function SettingsModal({ settings, onUpdate, onClose }: Props) {
  const [activeTab, setActiveTab] = useState<
    "sensors" | "cognitive" | "hardware" | "media"
  >("sensors");
  const [availableDevices, setAvailableDevices] = useState<
    { value: string; label: string }[]
  >([
    { value: "front", label: "Front Camera (Preset)" },
    { value: "back0", label: "Back Standard (Preset)" },
    { value: "back1", label: "Back Wide (Preset)" },
  ]);

  useEffect(() => {
    async function getDevices() {
      try {
        if (
          !navigator.mediaDevices ||
          !navigator.mediaDevices.enumerateDevices
        ) {
          return;
        }
        const allDevices = await navigator.mediaDevices.enumerateDevices();
        const videoDevices = allDevices.filter((d) => d.kind === "videoinput");

        if (videoDevices.length > 0) {
          const formatted = videoDevices.map((d, index) => {
            let label = d.label || `Camera ${index + 1}`;
            if (
              label.toLowerCase().includes("front") ||
              label.toLowerCase().includes("user")
            ) {
              label = `Front Camera (${index + 1})`;
            } else if (
              label.toLowerCase().includes("back") ||
              label.toLowerCase().includes("rear") ||
              label.toLowerCase().includes("environment")
            ) {
              label = `Back Camera ${index} (${label.substring(0, 15)})`;
            } else {
              label = `${label} (${index + 1})`;
            }
            return {
              value: d.deviceId,
              label: label,
            };
          });

          const combined = [
            { value: "front", label: "Front Camera (Preset)" },
            { value: "back0", label: "Back Standard (Preset)" },
            { value: "back1", label: "Back Wide (Preset)" },
            ...formatted.filter((d) => d.value !== ""),
          ];

          const unique = combined.reduce(
            (acc, current) => {
              const x = acc.find((item) => item.value === current.value);
              if (!x) {
                return acc.concat([current]);
              } else {
                return acc;
              }
            },
            [] as { value: string; label: string }[],
          );

          setAvailableDevices(unique);
        }
      } catch (err) {
        console.warn("Device enumeration failed, using presets", err);
      }
    }
    getDevices();
  }, []);

  const ParameterRow = ({
    label,
    keyName,
    min,
    max,
    step = 1,
    unit = "",
  }: {
    label: string;
    keyName: keyof SettingsConfig;
    min: number;
    max: number;
    step?: number;
    unit?: string;
  }) => (
    <div className="flex flex-col gap-1 mb-4">
      <div className="flex justify-between items-center font-mono text-xs text-cyber-cyan/80">
        <span>{label}</span>
        <span className="text-cyber-yellow">
          {Number(settings[keyName]).toFixed(1)}
          {unit}
        </span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={Number(settings[keyName])}
        onChange={(e) => onUpdate(keyName, parseFloat(e.target.value))}
        className="w-full accent-cyber-red cursor-pointer h-1.5 bg-cyber-darkred/30 appearance-none rounded-none"
      />
    </div>
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
      <div className="w-full max-w-lg border-2 border-cyber-red/60 bg-[#0a0005] flex flex-col h-[80vh]">
        {/* Header */}
        <div className="flex justify-between items-center p-3 border-b border-cyber-red/40 bg-cyber-red/10">
          <div className="flex items-center gap-2">
            <Sliders size={18} className="text-cyber-red" />
            <h2 className="font-orbitron font-bold text-cyber-red tracking-widest text-sm">
              SYSTEM SETUP
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 hover:bg-cyber-red/20 text-cyber-red transition-colors"
          >
            <X size={20} />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-cyber-cyan/30 text-[10px] font-orbitron text-cyber-cyan/60 tracking-widest overflow-x-auto custom-scrollbar">
          <button
            onClick={() => setActiveTab("cognitive")}
            className={`flex-1 p-2 border-r border-cyber-cyan/30 flex justify-center items-center gap-2 whitespace-nowrap px-4 ${activeTab === "cognitive" ? "bg-cyber-cyan/20 text-cyber-cyan" : "hover:bg-cyber-cyan/10"}`}
          >
            <Cpu size={12} /> COGNITIVE
          </button>
          <button
            onClick={() => setActiveTab("hardware")}
            className={`flex-1 p-2 border-r border-cyber-cyan/30 flex justify-center items-center gap-2 whitespace-nowrap px-4 ${activeTab === "hardware" ? "bg-cyber-cyan/20 text-cyber-cyan" : "hover:bg-cyber-cyan/10"}`}
          >
            <Sliders size={12} /> HARDWARE
          </button>
          <button
            onClick={() => setActiveTab("sensors")}
            className={`flex-1 p-2 border-r border-cyber-cyan/30 flex justify-center items-center gap-2 whitespace-nowrap px-4 ${activeTab === "sensors" ? "bg-cyber-cyan/20 text-cyber-cyan" : "hover:bg-cyber-cyan/10"}`}
          >
            <Camera size={12} /> VISION
          </button>
          <button
            onClick={() => setActiveTab("media")}
            className={`flex-1 p-2 flex justify-center items-center gap-2 whitespace-nowrap px-4 ${activeTab === "media" ? "bg-cyber-cyan/20 text-cyber-cyan" : "hover:bg-cyber-cyan/10"}`}
          >
            <Sliders size={12} /> MEDIA
          </button>
        </div>

        {/* Content */}
        <div className="p-5 overflow-y-auto custom-scrollbar flex-1">
          {activeTab === "sensors" && (
            <>
              <h3 className="font-orbitron text-xs text-cyber-cyan mb-3 border-b border-cyber-cyan/30 pb-1">
                VISION MODE
              </h3>
              <div className="flex gap-2 mb-6 font-mono text-[10px] text-cyber-cyan">
                <button
                  onClick={() => onUpdate("visualMode", "camera")}
                  className={`flex-1 py-1.5 border border-cyber-cyan/50 ${settings.visualMode === "camera" ? "bg-cyber-cyan text-black" : ""}`}
                >
                  CAMERA
                </button>
                <button
                  onClick={() => onUpdate("visualMode", "echolocation")}
                  className={`flex-1 py-1.5 border border-cyber-cyan/50 ${settings.visualMode === "echolocation" ? "bg-cyber-cyan text-black" : ""}`}
                >
                  ECHOLOCATION
                </button>
              </div>

              {settings.visualMode === "camera" && (
                <>
                  <div className="mb-4">
                    <span className="font-mono text-xs text-cyber-cyan/80 block mb-2">
                      Active Camera 1
                    </span>
                    <div className="flex flex-col gap-1 border border-cyber-cyan/20 p-1.5 bg-[#050011] max-h-[140px] overflow-y-auto">
                      {availableDevices.map((d) => (
                        <button
                          key={`cam1-${d.value}`}
                          type="button"
                          onClick={() => onUpdate("selectedCameraId", d.value)}
                          className={`w-full flex justify-between items-center px-2 py-1.5 font-mono text-[10px] border transition-all ${
                            settings.selectedCameraId === d.value
                              ? "bg-cyber-cyan/20 text-[#55ead4] border-cyber-cyan/60"
                              : "border-transparent text-cyber-cyan/65 hover:bg-cyber-cyan/10"
                          }`}
                        >
                          <span className="truncate pr-2">{d.label.toUpperCase()}</span>
                          <span className="text-[8px] font-bold shrink-0">
                            {settings.selectedCameraId === d.value ? "[ ACTIVE ]" : "[ SELECT ]"}
                          </span>
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="mb-4">
                    <div className="flex justify-between items-center mb-2">
                      <span className="font-mono text-xs text-cyber-cyan/80">
                        Active Camera 2
                      </span>
                      <button
                        onClick={() =>
                          onUpdate("enableCamera2", !settings.enableCamera2)
                        }
                        className={`px-2 py-0.5 text-[8px] font-mono border ${settings.enableCamera2 ? "bg-cyber-cyan text-black border-cyber-cyan" : "border-cyber-cyan/30 text-cyber-cyan/50"}`}
                      >
                        {settings.enableCamera2 ? "ON" : "OFF"}
                      </button>
                    </div>
                    {settings.enableCamera2 && (
                      <div className="flex flex-col gap-1 border border-cyber-cyan/20 p-1.5 bg-[#050011] max-h-[140px] overflow-y-auto">
                        {availableDevices.map((d) => (
                          <button
                            key={`cam2-${d.value}`}
                            type="button"
                            onClick={() => onUpdate("selectedCamera2Id", d.value)}
                            className={`w-full flex justify-between items-center px-2 py-1.5 font-mono text-[10px] border transition-all ${
                              settings.selectedCamera2Id === d.value
                                ? "bg-cyber-cyan/20 text-[#55ead4] border-cyber-cyan/60"
                                : "border-transparent text-cyber-cyan/65 hover:bg-cyber-cyan/10"
                            }`}
                          >
                            <span className="truncate pr-2">{d.label.toUpperCase()}</span>
                            <span className="text-[8px] font-bold shrink-0">
                              {settings.selectedCamera2Id === d.value ? "[ ACTIVE ]" : "[ SELECT ]"}
                            </span>
                          </button>
                        ))}
                      </div>
                    )}
                  </div>

                  <div className="flex justify-between items-center mb-6">
                    <span className="font-mono text-xs text-cyber-cyan/80">
                      Tactical Flashlight
                    </span>
                    <button
                      onClick={() =>
                        onUpdate("flashlightActive", !settings.flashlightActive)
                      }
                      className={`px-4 py-1 text-[10px] font-mono border ${settings.flashlightActive ? "bg-cyber-yellow text-black border-cyber-yellow" : "border-cyber-cyan/30 text-cyber-cyan/50"}`}
                    >
                      {settings.flashlightActive ? "ON" : "OFF"}
                    </button>
                  </div>

                  <h3 className="font-orbitron text-xs text-cyber-cyan mb-3 border-b border-cyber-cyan/30 pb-1">
                    OPTICS TUNING
                  </h3>
                  <ParameterRow
                    label="Contrast"
                    keyName="cameraContrast"
                    min={50}
                    max={200}
                    step={5}
                    unit="%"
                  />
                  <ParameterRow
                    label="Brightness"
                    keyName="cameraBrightness"
                    min={20}
                    max={150}
                    step={5}
                    unit="%"
                  />
                  <ParameterRow
                    label="Sepia Factor"
                    keyName="cameraSepia"
                    min={0}
                    max={100}
                    step={5}
                    unit="%"
                  />
                  <ParameterRow
                    label="Hue Rotate"
                    keyName="cameraHue"
                    min={0}
                    max={360}
                    step={10}
                    unit="°"
                  />

                  <h3 className="font-orbitron text-xs text-cyber-cyan mb-3 border-b border-cyber-cyan/30 pb-1 mt-6">
                    PERIPHERAL VISION EMULATION
                  </h3>
                  <ParameterRow
                    label="Edge Blur Radius"
                    keyName="peripheralBlur"
                    min={0}
                    max={30}
                    step={1}
                    unit="px"
                  />
                  <ParameterRow
                    label="Edge Pixelation Density"
                    keyName="peripheralPixelation"
                    min={0}
                    max={20}
                    step={1}
                    unit=""
                  />
                </>
              )}

              {settings.visualMode === "echolocation" && (
                <>
                  <h3 className="font-orbitron text-xs text-cyber-cyan mb-3 border-b border-cyber-cyan/30 pb-1">
                    SONAR TUNING
                  </h3>
                  <ParameterRow
                    label="Receiver Sensitivity"
                    keyName="echoSensitivity"
                    min={0.5}
                    max={3}
                    step={0.1}
                  />
                  <ParameterRow
                    label="Ping Range"
                    keyName="echoRange"
                    min={10}
                    max={200}
                    step={5}
                    unit="m"
                  />
                </>
              )}
            </>
          )}

          {activeTab === "cognitive" && (
            <>
              <h3 className="font-orbitron text-xs text-cyber-cyan mb-3 border-b border-cyber-cyan/30 pb-1">
                COGNITIVE PARAMETERS
              </h3>
              <ParameterRow
                label="Mimicry Pattern Match (Monkey See)"
                keyName="mimicryRate"
                min={0}
                max={100}
                unit="%"
              />
              <ParameterRow
                label="Linguistic Plasticity"
                keyName="linguisticPlasticity"
                min={0}
                max={100}
                unit="%"
              />
              <ParameterRow
                label="Curiosity Index"
                keyName="curiosityIndex"
                min={0.1}
                max={5}
                step={0.1}
              />
              <ParameterRow
                label="Memories Recorded Per Second"
                keyName="memoriesPerSecond"
                min={0.05}
                max={5}
                step={0.05}
                unit=" /s"
              />
              <ParameterRow
                label="Conscious/Subconscious Split Threshold"
                keyName="consciousThreshold"
                min={0}
                max={1}
                step={0.01}
              />
              <ParameterRow
                label="Dream Intensity Factor"
                keyName="dreamIntensity"
                min={0}
                max={10}
                step={0.1}
              />
              <ParameterRow
                label="Neural Learning Rate"
                keyName="learningRate"
                min={0.001}
                max={0.1}
                step={0.001}
              />
              <ParameterRow
                label="Emotional Weight Injection"
                keyName="emotionalWeightRate"
                min={0}
                max={100}
                unit="%"
              />
              <ParameterRow
                label="Memory Retention Decay Rate"
                keyName="memoryRetention"
                min={0}
                max={100}
                unit="%"
              />

              <div className="flex justify-between items-center mt-6 p-3 bg-cyber-cyan/10 border border-cyber-cyan/20">
                <span className="font-mono text-xs text-cyber-cyan/80">
                  Max Storage Pool (MB)
                </span>
                <input
                  type="number"
                  min="1"
                  max="99999"
                  value={settings.maxStoragePool}
                  onChange={(e) =>
                    onUpdate("maxStoragePool", parseInt(e.target.value))
                  }
                  className="bg-transparent border-b border-cyber-cyan text-cyber-cyan font-mono text-center w-20"
                />
              </div>

              <div className="flex justify-between items-center mt-2 p-3 bg-cyber-cyan/10 border border-cyber-cyan/20">
                <span className="font-mono text-xs text-cyber-cyan/80">
                  Scheduled REM Cycle (24h)
                </span>
                <input
                  type="number"
                  min="0"
                  max="23"
                  value={settings.dreamScheduleHour}
                  onChange={(e) =>
                    onUpdate("dreamScheduleHour", parseInt(e.target.value))
                  }
                  className="bg-transparent border-b border-cyber-cyan text-cyber-cyan font-mono text-center w-12"
                />
              </div>
            </>
          )}

          {activeTab === "hardware" && (
            <>
              <h3 className="font-orbitron text-xs text-cyber-cyan mb-3 border-b border-cyber-cyan/30 pb-1">
                RESOURCE ALLOCATION
              </h3>
              <ParameterRow
                label="CPU Core Allocation (Neural)"
                keyName="cpuAllocationCore"
                min={0}
                max={100}
                unit="%"
              />
              <ParameterRow
                label="CPU Vision Allocation"
                keyName="cpuAllocationVision"
                min={0}
                max={100}
                unit="%"
              />
              <ParameterRow
                label="GPU Acceleration Factor"
                keyName="gpuAllocation"
                min={0}
                max={100}
                unit="%"
              />
              <ParameterRow
                label="VRAM/RAM Block Reserved"
                keyName="ramAllocation"
                min={1}
                max={64}
                step={1}
                unit=" GB"
              />

              <h3 className="font-orbitron text-xs text-cyber-cyan mb-3 border-b border-cyber-cyan/30 pb-1 mt-6">
                CONSCIOUSNESS EMULATION
              </h3>
              <ParameterRow
                label="Critter Flicker Fusion Rate (CFF)"
                keyName="cffRate"
                min={10}
                max={144}
                step={1}
                unit=" Hz"
              />
              <ParameterRow
                label="Processing Unit Speed"
                keyName="processingSpeed"
                min={0.1}
                max={5}
                step={0.1}
                unit=" GHz"
              />
              <ParameterRow
                label="Neural Latency (Processing Delay)"
                keyName="simulationLag"
                min={0}
                max={1000}
                step={10}
                unit=" ms"
              />
              <ParameterRow
                label="Neural Density Matrix"
                keyName="neuralDensity"
                min={1}
                max={99999}
                step={1}
                unit=" nodes"
              />
              <div className="flex justify-between items-center mt-4">
                <span className="font-mono text-xs text-cyber-cyan/80 pl-2">
                  Render Actual Node Count (Grid)
                </span>
                <button
                  onClick={() =>
                    onUpdate("matchGridToNeurons", !settings.matchGridToNeurons)
                  }
                  className={`px-4 py-1 text-[10px] font-mono border ${settings.matchGridToNeurons ? "bg-cyber-cyan text-black border-cyber-cyan" : "border-cyber-cyan/30 text-cyber-cyan/50"}`}
                >
                  {settings.matchGridToNeurons ? "ON" : "OFF"}
                </button>
              </div>
            </>
          )}

          {activeTab === "media" && (
            <>
              <h3 className="font-orbitron text-xs text-cyber-cyan mb-3 border-b border-cyber-cyan/30 pb-1">
                AUDIO & MEDIA
              </h3>

              <div className="flex flex-col gap-2 mb-6">
                <span className="font-mono text-xs text-cyber-cyan/80">
                  Background Track (MP3)
                </span>
                <input
                  type="file"
                  accept="audio/mp3,audio/mpeg"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) {
                      const url = URL.createObjectURL(file);
                      onUpdate("bgmFile", url);
                    }
                  }}
                  className="text-xs font-mono text-cyber-cyan file:mr-4 file:py-1 file:px-4 file:border file:border-cyber-cyan/50 file:text-cyber-cyan file:bg-transparent hover:file:bg-cyber-cyan/10"
                />
                {settings.bgmFile && (
                  <span className="text-[10px] text-cyber-yellow">
                    Audio custom track loaded.
                  </span>
                )}
              </div>

              <div className="flex flex-col gap-2 mb-4">
                <span className="font-mono text-xs text-cyber-cyan/80">
                  Button Press SFX (MP3)
                </span>
                <input
                  type="file"
                  accept="audio/mp3,audio/mpeg"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) {
                      const url = URL.createObjectURL(file);
                      onUpdate("sfxFile", url);
                    }
                  }}
                  className="text-xs font-mono text-cyber-cyan file:mr-4 file:py-1 file:px-4 file:border file:border-cyber-cyan/50 file:text-cyber-cyan file:bg-transparent hover:file:bg-cyber-cyan/10"
                />
                {settings.sfxFile && (
                  <span className="text-[10px] text-cyber-yellow">
                    Audio custom SFX loaded.
                  </span>
                )}
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
