import { SensorPoint } from "../types";

interface Props {
  title: string;
  data: SensorPoint;
}

export function SensorReadout({ title, data }: Props) {
  return (
    <div className="p-4 border border-cyber-red/50 bg-cyber-black/80 backdrop-blur-md rounded-sm w-full max-w-[200px]">
      <h3 className="font-orbitron text-cyber-yellow text-sm mb-2 border-b border-cyber-red/30 pb-1">{title}</h3>
      <div className="font-mono text-xs flex flex-col gap-1">
        <div className="flex justify-between">
          <span className="text-cyber-cyan/70">X:</span>
          <span className="text-cyber-cyan">{data.x.toFixed(3)}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-cyber-cyan/70">Y:</span>
          <span className="text-cyber-cyan">{data.y.toFixed(3)}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-cyber-cyan/70">Z:</span>
          <span className="text-cyber-cyan">{data.z.toFixed(3)}</span>
        </div>
      </div>
    </div>
  );
}
