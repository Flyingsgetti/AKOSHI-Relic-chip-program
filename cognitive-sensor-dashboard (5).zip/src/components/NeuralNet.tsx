import { useEffect, useRef } from 'react';

export function NeuralNet({ totalNodes = 256, activeNodes = 144 }: { totalNodes?: number, activeNodes?: number }) {
  const squares = Array.from({ length: totalNodes });
  
  // Calculate which squares will be active this render
  // Instead of truly randomizing every frame the exact active instances, we just randomly pick exactly `activeNodes` to be lit
  const limitNodes = Math.min(activeNodes, totalNodes);
  
  // Create an array mapping to true for active ones, false otherwise
  // To keep it simple and visually appealing, we randomly shuffle active states
  const nodeStates = [...squares].map((_, i) => i < limitNodes).sort(() => Math.random() - 0.5);

  const gridCols = Math.ceil(Math.sqrt(totalNodes));
  
  return (
    <div className="flex flex-col items-center">
      <div className="relative w-48 h-48 mx-auto mb-4 rounded-full border border-cyber-cyan/50 bg-[#030014] shadow-[0_0_15px_rgba(85,234,212,0.1)] flex items-center justify-center overflow-hidden">
        {/* Crosshair marks */}
        <div className="absolute top-0 bottom-0 left-1/2 w-[1px] bg-cyber-cyan/20"></div>
        <div className="absolute left-0 right-0 top-1/2 h-[1px] bg-cyber-cyan/20"></div>
        <div className="absolute top-2 w-1 h-2 bg-cyber-cyan/60"></div>
        <div className="absolute bottom-2 w-1 h-2 bg-cyber-cyan/60"></div>
        <div className="absolute left-2 w-2 h-1 bg-cyber-cyan/60"></div>
        <div className="absolute right-2 w-2 h-1 bg-cyber-cyan/60"></div>
        
        <div 
          className="grid gap-[1px] w-32 h-32 p-2"
          style={{ gridTemplateColumns: `repeat(${gridCols}, minmax(0, 1fr))` }}
        >
          {nodeStates.map((isActive, i) => {
            return (
              <div 
                key={i} 
                className={`rounded-sm transition-colors duration-500 ${isActive ? 'bg-cyber-cyan' : 'bg-transparent'}`}
                style={{
                  opacity: isActive ? Math.random() * 0.4 + 0.6 : 0,
                  animation: isActive ? `pulse ${Math.random() * 3 + 1}s infinite alternate` : 'none'
                }}
              />
            )
          })}
        </div>
      </div>
      <div className="font-orbitron text-[10px] text-cyber-cyan/80 tracking-widest uppercase">
        {activeNodes} NEURAL NODES ACTIVE
      </div>
    </div>
  );
}
