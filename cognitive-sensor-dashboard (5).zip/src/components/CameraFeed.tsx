import { useRef, useEffect, useState } from "react";
import { Camera, Zap } from "lucide-react";
import { SettingsConfig, SensorPoint, Memory } from "../types";

interface Props {
  settings: SettingsConfig;
  gyro: SensorPoint;
  accel: SensorPoint;
  micLeft: number;
  micRight: number;
  dreamMode?: boolean;
  memories?: Memory[];
  isFeed2?: boolean;
}

export function CameraFeed({
  settings,
  gyro,
  accel,
  micLeft,
  micRight,
  dreamMode = false,
  memories = [],
  isFeed2 = false,
}: Props) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const dreamCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const simulatedCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [activeStream, setActiveStream] = useState<MediaStream | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);

  // 1. Boot up stream and save to state (only triggers when camera or mode changes)
  useEffect(() => {
    let active = true;
    let streamInstance: MediaStream | null = null;

    async function setupCamera() {
      if (
        settings.visualMode !== "camera" ||
        settings.selectedCameraId === "location" ||
        dreamMode
      ) {
        setActiveStream(null);
        if (videoRef.current) {
          videoRef.current.srcObject = null;
        }
        return;
      }

      setError(null);

      try {
        let videoConstraints: MediaTrackConstraints = {};
        if (settings.selectedCameraId === "front") {
          videoConstraints = { facingMode: "user" };
        } else if (settings.selectedCameraId === "back0") {
          videoConstraints = { facingMode: "environment" };
        } else if (settings.selectedCameraId === "back1") {
          videoConstraints = { facingMode: { ideal: "environment" } };
        } else if (settings.selectedCameraId) {
          videoConstraints = { deviceId: { ideal: settings.selectedCameraId } };
        } else {
          videoConstraints = { facingMode: "environment" };
        }

        const constraints: MediaStreamConstraints = {
          video: videoConstraints,
        };

        let stream: MediaStream | null = null;
        try {
          stream = await navigator.mediaDevices.getUserMedia(constraints);
        } catch (err) {
          console.warn(
            "Specific camera failed, falling back to any camera",
            err,
          );
          try {
            stream = await navigator.mediaDevices.getUserMedia({
              video: { facingMode: "environment" },
            });
          } catch (fallbackErr) {
            console.warn(
              "Standard fallback failed, attempting any video device",
              fallbackErr,
            );
            try {
              stream = await navigator.mediaDevices.getUserMedia({
                video: true,
              });
            } catch (finalErr) {
              const otherVideos = Array.from(
                document.querySelectorAll("video"),
              ).filter((v) => v !== videoRef.current && (v as any).srcObject);
              if (otherVideos.length > 0) {
                const otherStream = (otherVideos[0] as any)
                  .srcObject as MediaStream;
                if (otherStream && otherStream.active) {
                  console.log("Cloning existing active webcam stream.");
                  stream = otherStream.clone();
                }
              }
              if (!stream) {
                throw finalErr;
              }
            }
          }
        }

        if (!active) {
          if (stream) {
            stream.getTracks().forEach((track) => track.stop());
          }
          return;
        }

        streamInstance = stream;
        setActiveStream(stream);

        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.onloadedmetadata = () => {
            videoRef.current?.play()
              .then(() => setIsPlaying(true))
              .catch((playErr) => {
                console.warn("Autoplay blocked, user interaction required:", playErr);
                setIsPlaying(false);
              });
          };
        }
      } catch (err) {
        console.error("Camera completely disabled or unavailable", err);
        setError("Camera disabled or unavailable. Check permissions.");
      }
    }

    setupCamera();

    return () => {
      active = false;
      if (streamInstance) {
        streamInstance.getTracks().forEach((track) => track.stop());
      }
      if (videoRef.current) {
        videoRef.current.srcObject = null;
      }
    };
  }, [settings.visualMode, settings.selectedCameraId, dreamMode]);

  // 2. Control Flashlight Dynamically (Without tearing down the stream!)
  useEffect(() => {
    if (!activeStream) return;
    const track = activeStream.getVideoTracks()[0];
    if (!track) return;

    let timerId: any = null;

    async function applyFlashlight() {
      try {
        // Wait a short delay to ensure camera hardware is fully warmed up and active
        timerId = setTimeout(async () => {
          try {
            const capabilities = track.getCapabilities
              ? track.getCapabilities()
              : ({} as any);
            console.log("Track capabilities for flashlight:", capabilities);

            // Apply torch state (either true or false depending on flashlightActive)
            await track.applyConstraints({
              advanced: [{ torch: settings.flashlightActive } as any],
            });
            console.log(
              "Dynamic flashlight constraint applied successfully:",
              settings.flashlightActive,
            );
          } catch (innerErr) {
            console.warn(
              "Inner flashlight apply constraints failed:",
              innerErr,
            );
          }
        }, 250);
      } catch (e) {
        console.warn("Dynamic flashlight control call failed:", e);
      }
    }
    applyFlashlight();

    return () => {
      if (timerId) clearTimeout(timerId);
    };
  }, [activeStream, settings.flashlightActive]);

  // 3. Complete Dream Video Synthesis effect loop
  useEffect(() => {
    if (!dreamMode || isFeed2 || !dreamCanvasRef.current) return;
    const canvas = dreamCanvasRef.current;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animationId: number;
    let frame = 0;

    // Retrieve memories with valid image URLs
    const consciousMems = (memories || []).filter(m => m.type === "conscious" && m.imageUrl);
    const subconsciousMems = (memories || []).filter(m => m.type === "subconscious" && m.imageUrl);

    // Pre-load images inside the client to assure smooth rendering without flickering
    const loadedImages: { [id: string]: HTMLImageElement } = {};
    [...consciousMems, ...subconsciousMems].forEach(m => {
      if (m.imageUrl && !loadedImages[m.id]) {
        const img = new Image();
        img.src = m.imageUrl;
        loadedImages[m.id] = img;
      }
    });

    const render = () => {
      frame++;
      const width = canvas.width;
      const height = canvas.height;

      // Dark purple backdrop cycle
      ctx.fillStyle = "#090014";
      ctx.fillRect(0, 0, width, height);

      // Morphing cyan network grid lines representing dream logic
      ctx.strokeStyle = "rgba(85, 234, 212, 0.12)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      for (let i = 0; i < width; i += 16) {
        // Shift lines horizontally based on sine waves
        const offset = Math.sin((i + frame) * 0.02) * 20;
        ctx.moveTo(i, 0);
        ctx.lineTo(i + offset, height);
      }
      ctx.stroke();

      const hasConscious = consciousMems.length > 0;
      const hasSubconscious = subconsciousMems.length > 0;

      if (hasConscious || hasSubconscious) {
        // Switch memory anchors every 120 frames (2 seconds)
        const cycleFrames = 120;
        const indexCycle = Math.floor(frame / cycleFrames);

        const consciousMem = hasConscious ? consciousMems[indexCycle % consciousMems.length] : null;
        const subconsciousMem = hasSubconscious ? subconsciousMems[(indexCycle + 1) % subconsciousMems.length] : null;

        // Render base conscious memory (Whole Scene)
        if (consciousMem && loadedImages[consciousMem.id]?.complete) {
          const img = loadedImages[consciousMem.id];
          ctx.save();
          // Slow organic scaling and rotation simulating floating dreams
          const scale = 1.1 + Math.sin(frame * 0.008) * 0.08;
          const angle = Math.cos(frame * 0.004) * 0.04;
          ctx.translate(width / 2, height / 2);
          ctx.scale(scale, scale);
          ctx.rotate(angle);
          ctx.globalAlpha = 0.65;
          ctx.drawImage(img, -width / 2, -height / 2, width, height);
          ctx.restore();
        }

        // Overlay subconscious memory (Cropped detail, sliding across screen)
        if (subconsciousMem && loadedImages[subconsciousMem.id]?.complete) {
          const img = loadedImages[subconsciousMem.id];
          ctx.save();
          ctx.globalCompositeOperation = "screen";
          // Pulsing opacity
          ctx.globalAlpha = 0.45 + Math.sin(frame * 0.02) * 0.15;
          
          // Smooth floating path
          const slideX = Math.sin(frame * 0.006) * (width / 5);
          const slideY = Math.cos(frame * 0.005) * (height / 5);
          
          ctx.translate(width / 2 + slideX, height / 2 + slideY);
          // Scale down and spin detail
          ctx.scale(0.55, 0.55);
          ctx.rotate(frame * 0.002);
          ctx.drawImage(img, -width / 2, -height / 2, width, height);
          ctx.restore();
        }
      } else {
        // Procedural dream pattern if no memories are stored yet
        ctx.strokeStyle = "rgba(243, 230, 0, 0.45)";
        ctx.lineWidth = 1;
        ctx.beginPath();
        for (let i = 0; i < 4; i++) {
          const rad = 25 + i * 18 + Math.sin((frame + i * 15) * 0.04) * 10;
          ctx.arc(width / 2, height / 2, rad, 0, Math.PI * 2);
        }
        ctx.stroke();

        ctx.fillStyle = "#55ead4";
        for (let i = 0; i < 6; i++) {
          const angle = (i * Math.PI / 3) + (frame * 0.003);
          const x = width / 2 + Math.cos(angle) * 55;
          const y = height / 2 + Math.sin(angle) * 55;
          ctx.beginPath();
          ctx.arc(x, y, 3 + Math.sin((frame + i) * 0.08) * 1.5, 0, Math.PI * 2);
          ctx.fill();

          ctx.strokeStyle = "rgba(85, 234, 212, 0.2)";
          ctx.beginPath();
          ctx.moveTo(width / 2, height / 2);
          ctx.lineTo(x, y);
          ctx.stroke();
        }
      }

      // Draw digital HUD overlays over the dream feed
      ctx.fillStyle = "#f3e600";
      ctx.font = "8px monospace";
      ctx.fillText("REM_DREAM_PROJECTION: ONLINE", 10, 18);
      ctx.fillText(`SYNTH_FRAME: ${frame}`, 10, 28);
      ctx.fillText("MOD: DEEP REM SLEEP GENERATION", 10, 38);

      // Procedural scanlines
      ctx.fillStyle = "rgba(255, 255, 255, 0.03)";
      for (let y = 0; y < height; y += 4) {
        ctx.fillRect(0, y, width, 1.5);
      }

      // Spontaneous micro-glitch bars
      if (Math.random() > 0.97) {
        ctx.fillStyle = "rgba(85, 234, 212, 0.3)";
        ctx.fillRect(0, Math.random() * height, width, Math.random() * 6);
      }

      animationId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationId);
    };
  }, [dreamMode, isFeed2, memories]);

  // 4. Simulated Camera Feed Synthesis Loop (Fallback)
  useEffect(() => {
    if (!error || dreamMode || settings.visualMode !== "camera" || !simulatedCanvasRef.current) return;
    const canvas = simulatedCanvasRef.current;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animationId: number;
    let frame = 0;

    // Static coordinates for nodes to scan
    const targets = [
      { id: "SYS_COR", name: "CORTEX NODE", x: 160, y: 90, r: 15, tag: "STABLE" },
      { id: "BIO_SGN", name: "COGNITIVE CONSTRUCT", x: 80, y: 120, r: 8, tag: "NEURAL_LINK" },
      { id: "FAC_RET", name: "HUMAN SUBJECT", x: 240, y: 70, r: 24, tag: "MATCH: 98.4%" }
    ];

    const render = () => {
      frame++;
      const width = canvas.width;
      const height = canvas.height;

      // Dark sci-fi background with deep blue/green undertone
      ctx.fillStyle = "#010813";
      ctx.fillRect(0, 0, width, height);

      // Rotating complex vector compass or grid pattern using gyro
      ctx.save();
      ctx.translate(width / 2, height / 2);
      // Let gyro-responsive tilts affect the grid coordinates
      const tiltX = (gyro.y || 0) * 0.4;
      const tiltY = (gyro.x || 0) * 0.4;
      ctx.translate(tiltX, tiltY);

      // Orbit/grid background lines
      ctx.strokeStyle = "rgba(85, 234, 212, 0.08)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      for (let i = -width; i < width * 2; i += 24) {
        ctx.moveTo(i, -height);
        ctx.lineTo(i + (gyro.z || 0) * 0.5, height * 2);
      }
      ctx.stroke();

      // Scan radar circles
      ctx.strokeStyle = "rgba(85, 234, 212, 0.15)";
      ctx.beginPath();
      ctx.arc(0, 0, 50, 0, Math.PI * 2);
      ctx.arc(0, 0, 90, 0, Math.PI * 2);
      ctx.stroke();

      // Sweeping radar arm mirroring radar frequencies
      const sweepAngle = (frame * 0.015) % (Math.PI * 2);
      ctx.strokeStyle = "rgba(85, 234, 212, 0.3)";
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(Math.cos(sweepAngle) * 120, Math.sin(sweepAngle) * 120);
      ctx.stroke();

      // Draw simulated target nodes
      targets.forEach((tgt, index) => {
        // Organic breathing movement of targets
        const mx = tgt.x + Math.sin(frame * 0.01 + index * 10) * 20;
        const my = tgt.y + Math.cos(frame * 0.012 + index * 5) * 15;
        
        const screenX = mx - width / 2;
        const screenY = my - height / 2;

        ctx.strokeStyle = "#55ead4";
        ctx.lineWidth = 1;
        ctx.beginPath();
        // Inner reticle circle
        ctx.arc(screenX, screenY, tgt.r + Math.sin(frame * 0.05) * 2, 0, Math.PI * 2);
        ctx.stroke();

        // Corner bracket lines
        const bs = tgt.r * 1.3;
        ctx.strokeStyle = "rgba(85, 234, 212, 0.7)";
        ctx.beginPath();
        // Top-Left corner
        ctx.moveTo(screenX - bs, screenY - bs + 4);
        ctx.lineTo(screenX - bs, screenY - bs);
        ctx.lineTo(screenX - bs + 4, screenY - bs);
        // Top-Right corner
        ctx.moveTo(screenX + bs, screenY - bs + 4);
        ctx.lineTo(screenX + bs, screenY - bs);
        ctx.lineTo(screenX + bs - 4, screenY - bs);
        // Bottom-Left corner
        ctx.moveTo(screenX - bs, screenY + bs - 4);
        ctx.lineTo(screenX - bs, screenY + bs);
        ctx.lineTo(screenX - bs + 4, screenY + bs);
        // Bottom-Right corner
        ctx.moveTo(screenX + bs, screenY + bs - 4);
        ctx.lineTo(screenX + bs, screenY + bs);
        ctx.lineTo(screenX + bs - 4, screenY + bs);
        ctx.stroke();

        // Target HUD Labels
        ctx.fillStyle = "#55ead4";
        ctx.font = "6px monospace";
        ctx.fillText(tgt.name, screenX + bs + 4, screenY - 2);
        ctx.fillStyle = "rgba(85, 234, 212, 0.6)";
        ctx.fillText(`[${tgt.id}]: ${tgt.tag}`, screenX + bs + 4, screenY + 6);
      });

      // Sound reactive core matrix
      const maxMic = Math.max(micLeft, micRight);
      const pulseRadius = 15 + maxMic * 0.6;
      ctx.strokeStyle = "rgba(243, 230, 0, 0.6)";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(0, 0, pulseRadius, 0, Math.PI * 2);
      ctx.stroke();

      ctx.fillStyle = "rgba(243, 230, 0, 0.15)";
      ctx.fill();

      ctx.restore();

      // Ambient HUD labels overlayed
      ctx.fillStyle = "rgba(85, 234, 212, 0.85)";
      ctx.font = "8px monospace";
      ctx.fillText(`VECTOR_SIM_TIME: ${Date.now()}`, 10, 18);
      ctx.fillText(`SYS_ORIENT_X: ${(gyro.x || 0).toFixed(1)}°`, 10, 28);
      ctx.fillText(`SYS_ORIENT_Y: ${(gyro.y || 0).toFixed(1)}°`, 10, 38);
      ctx.fillText(`MIC_INPUT_ENERGY: ${maxMic.toFixed(1)}%`, 10, 48);

      // Grid corner brackets
      ctx.strokeStyle = "rgba(85, 234, 212, 0.3)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      // Top left
      ctx.moveTo(10, 20); ctx.lineTo(10, 10); ctx.lineTo(20, 10);
      // Top right
      ctx.moveTo(width - 10, 20); ctx.lineTo(width - 10, 10); ctx.lineTo(width - 20, 10);
      // Bottom left
      ctx.moveTo(10, height - 20); ctx.lineTo(10, height - 10); ctx.lineTo(20, height - 10);
      // Bottom right
      ctx.moveTo(width - 10, height - 20); ctx.lineTo(width - 10, height - 10); ctx.lineTo(width - 20, height - 10);
      ctx.stroke();

      // Procedural scanlines
      ctx.fillStyle = "rgba(255, 255, 255, 0.02)";
      for (let y = 0; y < height; y += 3) {
        ctx.fillRect(0, y, width, 1);
      }

      // Live sweeping static glitches
      if (Math.random() > 0.98) {
        ctx.fillStyle = "rgba(85, 234, 212, 0.2)";
        ctx.fillRect(0, Math.random() * height, width, Math.random() * 4);
      }

      animationId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationId);
    };
  }, [error, dreamMode, settings.visualMode, gyro, micLeft, micRight]);

  const cssFilter = `contrast(${settings.cameraContrast}%) saturate(${settings.cameraHue === 0 ? 0 : 100}%) sepia(${settings.cameraSepia}%) hue-rotate(${settings.cameraHue}deg) brightness(${settings.cameraBrightness}%)`;

  const showPeripheral = (settings.visualMode === "camera" || dreamMode) && (settings.peripheralBlur > 0 || settings.peripheralPixelation > 0);

  return (
    <div className="w-full h-full relative cursor-crosshair overflow-hidden">
      {dreamMode ? (
        isFeed2 ? (
          <div className="absolute inset-0 bg-[#06000c] flex flex-col items-center justify-center text-center p-3">
            <span className="font-orbitron text-cyber-yellow text-[9px] tracking-[0.2em] mb-1 animate-pulse">REM CONSOLIDATION</span>
            <span className="font-mono text-[8px] text-[#55ead4]/50 leading-relaxed">[ CAMERA OFFLINE ]</span>
            <div className="w-8 h-[1px] bg-cyber-yellow/40 mt-3 animate-pulse" />
          </div>
        ) : (
          <div className="w-full h-full relative bg-[#06000c]">
            <canvas 
              ref={dreamCanvasRef} 
              width={320} 
              height={180} 
              className="w-full h-full object-cover dream-feed"
              style={{ filter: cssFilter }}
            />
            <div className="absolute bottom-1.5 left-1.5 flex items-center gap-1.5 font-mono text-[7px] text-cyber-yellow bg-black/75 px-1 py-0.5 border border-cyber-yellow/20">
              <span className="w-1 h-1 bg-cyber-yellow rounded-full animate-ping" />
              <span>PRODUCING SYNTHESIZED DREAM</span>
            </div>
          </div>
        )
      ) : settings.selectedCameraId === "location" ? (
        <div className="absolute inset-0 bg-[#000510] flex flex-col items-center justify-center relative overflow-hidden">
          <div className="absolute font-orbitron text-cyber-cyan/30 text-[8px] top-2 left-2 z-10">
            GPS SATELLITE LINK ACTIVE
          </div>
          <div className="font-mono text-cyber-cyan text-xs drop-shadow-[0_0_5px_#55ead4]">
            AQUIRING SATELLITE LOCK...
          </div>
          <div className="mt-4 font-mono text-[10px] text-cyber-cyan/80">
            LAT: 37.7749° N
          </div>
          <div className="font-mono text-[10px] text-cyber-cyan/80">
            LNG: -122.4194° W
          </div>

          <div className="absolute inset-0 border-2 border-cyber-cyan/20 rounded-full w-24 h-24 m-auto opacity-50" />
          <div className="absolute inset-0 border border-cyber-cyan/10 rounded-full w-36 h-36 m-auto opacity-30" />
          <div
            className="absolute top-1/2 left-1/2 w-16 h-1 bg-gradient-to-r from-transparent to-cyber-cyan/80 origin-left animate-spin"
            style={{ animationDuration: "3s" }}
          />
          <div className="absolute top-1/2 left-1/2 w-1 h-1 bg-cyber-cyan rounded-full -translate-x-1/2 -translate-y-1/2 shadow-[0_0_8px_#55ead4]" />
        </div>
      ) : settings.visualMode === "echolocation" ? (
        <div className="absolute inset-0 bg-[#000510] flex items-center justify-center relative overflow-hidden">
          <div className="absolute font-orbitron text-cyber-cyan/30 text-[8px] top-2 left-2 z-10">
            SONAR MAPPER ACTIVE / CFF: {settings.cffRate}HZ
          </div>

          {/* Echolocation rings based on mic */}
          <div
            className="absolute rounded-full border border-[#55ead4]/30"
            style={{
              width: `${micLeft * 3 * settings.echoSensitivity}px`,
              height: `${micLeft * 3 * settings.echoSensitivity}px`,
              transform: `translate(${gyro.y / 2}px, ${gyro.x / 2}px)`,
              opacity: 1 - micLeft / 100,
            }}
          />
          <div
            className="absolute rounded-full border border-cyber-yellow/30"
            style={{
              width: `${micRight * 3 * settings.echoSensitivity}px`,
              height: `${micRight * 3 * settings.echoSensitivity}px`,
              transform: `translate(${-gyro.y / 2}px, ${-gyro.x / 2}px)`,
              opacity: 1 - micRight / 100,
              transition: "all 0.1s linear",
            }}
          />

          {/* Grid floor tilt representing accel */}
          <div
            className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_20%,#000_100%)] z-10 border-t border-cyber-cyan/20"
            style={{
              transform: `perspective(400px) rotateX(${60 + accel.y * 10}deg) translateY(${accel.z * 50}px)`,
            }}
          >
            <div className="w-[200%] h-[200%] absolute -left-[50%] -top-[50%] bg-[linear-gradient(rgba(85,234,212,0.1)_1px,transparent_1px),linear-gradient(90deg,rgba(85,234,212,0.1)_1px,transparent_1px)] bg-[length:40px_40px]" />
          </div>
        </div>
      ) : error ? (
        <div className="w-full h-full relative bg-[#01050e]">
          <canvas
            ref={simulatedCanvasRef}
            width={320}
            height={180}
            className="w-full h-full object-cover simulated-feed block"
            style={{ filter: cssFilter }}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/20 pointer-events-none" />
          <div className="absolute bottom-1.5 left-1.5 flex flex-col gap-0.5 font-mono text-[7px] text-[#55ead4] bg-black/85 px-1.5 py-1 border border-[#55ead4]/30 z-10">
            <div className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 bg-[#55ead4] rounded-full animate-ping" />
              <span className="font-orbitron font-semibold tracking-wider">OPTICAL SIMULATOR: LIVE</span>
            </div>
            <span className="text-[#55ead4]/50 text-[6px]">HARDWARE OFFLINE: PERMISSION RESTRICTED</span>
          </div>
        </div>
      ) : (
        <div className="w-full h-full relative">
          <video
            ref={videoRef}
            autoPlay
            playsInline
            muted
            onPlay={() => setIsPlaying(true)}
            onPause={() => setIsPlaying(false)}
            onClick={() => {
              videoRef.current?.play()
                .then(() => setIsPlaying(true))
                .catch(err => console.warn("Video play error:", err));
            }}
            className="w-full h-full object-cover opacity-100 block cursor-pointer"
            style={{ filter: cssFilter }}
          />
          {!isPlaying && !error && settings.selectedCameraId !== "location" && (
            <div 
              onClick={() => {
                videoRef.current?.play()
                  .then(() => setIsPlaying(true))
                  .catch(err => console.warn("Video play error:", err));
              }}
              className="absolute inset-0 bg-black/70 flex flex-col items-center justify-center cursor-pointer z-10 transition-all duration-300 hover:bg-black/55"
            >
              <Camera size={18} className="text-cyber-cyan animate-pulse mb-1" />
              <span className="font-mono text-[9px] text-cyber-cyan tracking-[0.2em] animate-pulse text-center px-2">
                [ TAP TO INITIATE OPTICAL FEED ]
              </span>
            </div>
          )}
        </div>
      )}

      {/* Hardware-Accelerated Peripheral Vision Masking Overlay */}
      {showPeripheral && (
        <div 
          className="absolute inset-0 pointer-events-none z-10 transition-all duration-300"
          style={{
            backdropFilter: settings.peripheralBlur > 0 ? `blur(${settings.peripheralBlur}px)` : 'none',
            WebkitBackdropFilter: settings.peripheralBlur > 0 ? `blur(${settings.peripheralBlur}px)` : 'none',
            backgroundImage: settings.peripheralPixelation > 0 
              ? `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='${Math.max(4, 32 - settings.peripheralPixelation * 1.5)}' height='${Math.max(4, 32 - settings.peripheralPixelation * 1.5)}' viewBox='0 0 20 20'%3E%3Crect width='20' height='20' fill='none' stroke='rgba(85,234,212,${settings.peripheralPixelation / 35})' stroke-width='1.5'/%3E%3C/svg%3E")`
              : 'none',
            backgroundSize: settings.peripheralPixelation > 0 ? `${Math.max(6, 24 - settings.peripheralPixelation)}px ${Math.max(6, 24 - settings.peripheralPixelation)}px` : 'auto',
            maskImage: 'radial-gradient(circle, transparent 35%, black 85%)',
            WebkitMaskImage: 'radial-gradient(circle, transparent 35%, black 85%)',
          }}
        />
      )}

      {/* Target Cross => Image equivalent styling */}
      <div className="absolute inset-0 pointer-events-none border border-cyber-cyan/10 z-20">
        <div className="absolute top-1/2 left-0 w-2 h-[1px] bg-cyber-cyan/50" />
        <div className="absolute top-1/2 right-0 w-2 h-[1px] bg-cyber-cyan/50" />
        <div className="absolute left-1/2 top-0 h-2 w-[1px] bg-cyber-cyan/50" />
        <div className="absolute left-1/2 bottom-0 h-2 w-[1px] bg-cyber-cyan/50" />

        {settings.visualMode === "camera" && settings.flashlightActive && (
          <div className="absolute bottom-2 right-2 text-cyber-yellow/80 flex items-center gap-1 font-mono text-[8px] bg-black/50 px-1 py-0.5 rounded-sm">
            <Zap size={10} className="fill-current" /> FLASHLIGHT ON
          </div>
        )}
      </div>
    </div>
  );
}
