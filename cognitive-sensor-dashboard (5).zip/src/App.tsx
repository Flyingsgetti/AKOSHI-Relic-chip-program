import { useState, useEffect, useCallback, useRef } from 'react';
import { HexBackground } from './components/HexBackground';
import { ConstellationBackground } from './components/ConstellationBackground';
import { AxisIndicator } from './components/AxisIndicator';
import { NeuralNet } from './components/NeuralNet';
import { CameraFeed } from './components/CameraFeed';
import { ControlPanel } from './components/ControlPanel';
import { GalleryModal } from './components/GalleryModal';
import { SettingsModal } from './components/SettingsModal';
import { Memory, SettingsConfig } from './types';

const captureCameraSnapshot = (type: 'conscious' | 'subconscious' | 'dream'): string | undefined => {
  try {
    const videoElements = document.querySelectorAll('video');
    if (videoElements.length > 0) {
      const activeVideos = Array.from(videoElements).filter(
        v => v.readyState >= 2 && !v.paused && v.videoWidth > 0
      );
      if (activeVideos.length > 0) {
        const video = activeVideos[Math.floor(Math.random() * activeVideos.length)];
        const canvas = document.createElement('canvas');
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          if (type === 'subconscious') {
            // Focus on a random detail of the scene (cropping 40-45% of the page size)
            const targetWidth = video.videoWidth * 0.45;
            const targetHeight = video.videoHeight * 0.45;
            // Align in center-outer coordinates randomly
            const cropX = (video.videoWidth - targetWidth) * (0.2 + Math.random() * 0.6);
            const cropY = (video.videoHeight - targetHeight) * (0.2 + Math.random() * 0.6);
            
            // Draw zoom detail
            ctx.drawImage(video, cropX, cropY, targetWidth, targetHeight, 0, 0, canvas.width, canvas.height);
            
            // Render autofocus reticles
            ctx.strokeStyle = '#55ead4';
            ctx.lineWidth = Math.max(2, video.videoWidth * 0.005);
            const pad = canvas.width * 0.05;
            const blen = canvas.width * 0.12;
            
            // Brackets
            ctx.beginPath();
            ctx.moveTo(pad, pad + blen); ctx.lineTo(pad, pad); ctx.lineTo(pad + blen, pad);
            ctx.stroke();
            ctx.beginPath();
            ctx.moveTo(canvas.width - pad, pad + blen); ctx.lineTo(canvas.width - pad, pad); ctx.lineTo(canvas.width - pad - blen, pad);
            ctx.stroke();
            ctx.beginPath();
            ctx.moveTo(pad, canvas.height - pad - blen); ctx.lineTo(pad, canvas.height - pad); ctx.lineTo(pad + blen, canvas.height - pad);
            ctx.stroke();
            ctx.beginPath();
            ctx.moveTo(canvas.width - pad, canvas.height - pad - blen); ctx.lineTo(canvas.width - pad, canvas.height - pad); ctx.lineTo(canvas.width - pad - blen, canvas.height - pad);
            ctx.stroke();

            ctx.fillStyle = '#55ead4';
            ctx.font = `${Math.max(8, Math.floor(canvas.width * 0.025))}px monospace`;
            ctx.fillText("[SUBCONSCIOUS OPTICS: DETAIL ENHANCED]", pad * 1.5, pad * 2.8);
          } else {
            // Conscious visual: captures whole panoramic frame scene
            ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
          }
          return canvas.toDataURL('image/jpeg', 0.6);
        }
      }
    }

    // Capture fallback from active simulated canvas elements
    const activeCanvas = document.querySelector('canvas.dream-feed') as HTMLCanvasElement || 
                         document.querySelector('canvas.simulated-feed') as HTMLCanvasElement;
    if (activeCanvas) {
      const canvas = document.createElement('canvas');
      canvas.width = activeCanvas.width;
      canvas.height = activeCanvas.height;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        if (type === 'subconscious') {
          // Enhancing/cropping simulated canvas details
          const targetWidth = activeCanvas.width * 0.45;
          const targetHeight = activeCanvas.height * 0.45;
          const cropX = (activeCanvas.width - targetWidth) * (0.2 + Math.random() * 0.6);
          const cropY = (activeCanvas.height - targetHeight) * (0.2 + Math.random() * 0.6);
          ctx.drawImage(activeCanvas, cropX, cropY, targetWidth, targetHeight, 0, 0, canvas.width, canvas.height);
          
          ctx.strokeStyle = '#55ead4';
          ctx.lineWidth = 1.5;
          const pad = canvas.width * 0.05;
          const blen = canvas.width * 0.12;
          ctx.beginPath();
          ctx.moveTo(pad, pad + blen); ctx.lineTo(pad, pad); ctx.lineTo(pad + blen, pad);
          ctx.stroke();
          ctx.beginPath();
          ctx.moveTo(canvas.width - pad, pad + blen); ctx.lineTo(canvas.width - pad, pad); ctx.lineTo(canvas.width - pad - blen, pad);
          ctx.stroke();
          
          ctx.fillStyle = '#55ead4';
          ctx.font = '7px monospace';
          ctx.fillText("[SUBCONSCIOUS SIMULATOR TRACE]", pad * 1.5, pad * 2.8);
        } else {
          ctx.drawImage(activeCanvas, 0, 0, canvas.width, canvas.height);
        }
        return canvas.toDataURL('image/jpeg', 0.6);
      }
    }
  } catch (e) {
    console.warn("Failed to capture active camera or canvas snapshot:", e);
  }
  return undefined;
};

const generateOfflineSensorySnapshot = (type: 'conscious' | 'subconscious' | 'dream', sensors: any, emotion: string): string => {
  const canvas = document.createElement('canvas');
  canvas.width = 160;
  canvas.height = 160;
  const ctx = canvas.getContext('2d');
  if (ctx) {
    // Fill deep cyberpunk backdrop
    ctx.fillStyle = '#05001a';
    ctx.fillRect(0, 0, 160, 160);
    
    // Draw neon grid lines
    ctx.strokeStyle = type === 'dream' ? 'rgba(243, 230, 0, 0.25)' : type === 'conscious' ? 'rgba(85, 234, 212, 0.2)' : 'rgba(85, 234, 212, 0.1)';
    ctx.lineWidth = 1;
    for (let i = 20; i < 160; i += 30) {
      ctx.beginPath();
      ctx.moveTo(i, 0); ctx.lineTo(i, 160);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(0, i); ctx.lineTo(160, i);
      ctx.stroke();
    }
    
    if (type === 'subconscious') {
      // Draw sub-detailed radar targeting layout representing subconscious focal point
      ctx.strokeStyle = '#55ead4';
      ctx.lineWidth = 1.5;
      
      ctx.beginPath();
      ctx.arc(80, 80, 26, 0, Math.PI * 2);
      ctx.stroke();
      
      ctx.beginPath();
      ctx.arc(80, 80, 4, 0, Math.PI * 2);
      ctx.fillStyle = '#55ead4';
      ctx.fill();

      ctx.beginPath();
      ctx.moveTo(40, 80); ctx.lineTo(58, 80);
      ctx.moveTo(102, 80); ctx.lineTo(120, 80);
      ctx.moveTo(80, 40); ctx.lineTo(80, 58);
      ctx.moveTo(80, 102); ctx.lineTo(80, 120);
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(35, 60); ctx.lineTo(35, 35); ctx.lineTo(60, 35);
      ctx.moveTo(125, 60); ctx.lineTo(125, 35); ctx.lineTo(100, 35);
      ctx.moveTo(35, 100); ctx.lineTo(35, 125); ctx.lineTo(60, 125);
      ctx.moveTo(125, 100); ctx.lineTo(125, 125); ctx.lineTo(100, 125);
      ctx.stroke();

      ctx.strokeStyle = 'rgba(85, 234, 212, 0.5)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      for (let x = 45; x < 115; x += 3) {
        const y = 80 + Math.sin(x * 0.4) * 8;
        ctx.lineTo(x, y);
      }
      ctx.stroke();
    } else {
      ctx.lineWidth = 1.8;
      ctx.strokeStyle = type === 'dream' ? '#f3e600' : '#55ead4';
      ctx.beginPath();
      const phase = (sensors.heading || 0) * Math.PI / 180;
      
      if (emotion === 'happy') {
        ctx.arc(80, 80, 45, 0, Math.PI * 2);
        ctx.stroke();
        ctx.beginPath();
        ctx.arc(80, 80, 20, 0, Math.PI * 2);
      } else if (emotion === 'angry') {
        ctx.moveTo(10, 80);
        for (let x = 20; x < 155; x += 15) {
          const y = 80 + (Math.sin(x + phase) * 35) + (Math.random() * 24 - 12);
          ctx.lineTo(x, y);
        }
      } else if (emotion === 'sad') {
        ctx.moveTo(10, 80);
        for (let x = 10; x < 150; x += 10) {
          const y = 80 + Math.sin(x * 0.05 + phase) * 15 * (1 - x / 150);
          ctx.lineTo(x, y);
        }
      } else {
        ctx.moveTo(10, 80);
        for (let x = 10; x < 155; x += 5) {
          const y = 80 + Math.sin(x * 0.1 + phase) * 20;
          ctx.lineTo(x, y);
        }
      }
      ctx.stroke();
    }
    
    ctx.fillStyle = type === 'dream' ? 'rgba(243, 230, 0, 0.85)' : 'rgba(85, 234, 212, 0.85)';
    ctx.font = '8px monospace';
    ctx.fillText(`SYS_REC_${type.toUpperCase()}`, 12, 22);
    ctx.fillText(`EM: ${emotion.toUpperCase()}`, 12, 142);
    ctx.fillText(`HEAD: ${(sensors.heading || 0).toFixed(0)}°`, 100, 142);
  }
  return canvas.toDataURL('image/jpeg', 0.6);
};

export default function App() {
  const [isRecording, setIsRecording] = useState(false);
  const [dreamMode, setDreamMode] = useState(false);
  const [ping, setPing] = useState(24);
  
  const [showGallery, setShowGallery] = useState(false);
  const [showSettings, setShowSettings] = useState(false);

  const [gyro, setGyro] = useState({ x: 0.1, y: -161.5, z: -62.7 });
  const [gyroOffset, setGyroOffset] = useState({ x: 0, y: 0, z: 0 });
  const gyroOffsetRef = useRef({ x: 0, y: 0, z: 0 });
  const rawGyroRef = useRef({ x: 0, y: 0, z: 0 });

  const [accel, setAccel] = useState({ x: -0.032, y: -0.466, z: 0.827 });
  const [micLeft, setMicLeft] = useState(0);
  const [micRight, setMicRight] = useState(0);
  const [memories, setMemories] = useState<Memory[]>([]);
  const [heading, setHeading] = useState(297);
  
  const [currentCpu, setCurrentCpu] = useState(0);
  const [currentGpu, setCurrentGpu] = useState(0);
  const [currentRam, setCurrentRam] = useState(0);
  const [cpuHistory, setCpuHistory] = useState<number[]>(Array(10).fill(10));

  const [settings, setSettings] = useState<SettingsConfig>({
    processingSpeed: 2.1,
    neuralDensity: 256,
    simulationLag: 0,
    learningRate: 0.024,
    dreamIntensity: 5.0,
    consciousThreshold: 0.7,
    emotionalWeightRate: 50,
    memoryRetention: 85,
    visualMode: 'camera',
    flashlightActive: false,
    cameraContrast: 125,
    cameraSepia: 50,
    cameraHue: 190,
    cameraBrightness: 70,
    echoSensitivity: 1.0,
    echoRange: 50,
    dreamScheduleHour: 22,
    cffRate: 60,
    selectedCameraId: 'front',
    selectedCamera2Id: 'back0',
    enableCamera2: false,
    cpuAllocationCore: 48,
    cpuAllocationVision: 32,
    gpuAllocation: 85,
    ramAllocation: 4,
    peripheralBlur: 10,
    peripheralPixelation: 8,
    mimicryRate: 60,
    linguisticPlasticity: 40,
    curiosityIndex: 2.5,
    matchGridToNeurons: false,
    maxStoragePool: 1024,
    memoriesPerSecond: 0.5
  });

  const updateSetting = useCallback((key: keyof SettingsConfig, value: any) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  }, []);

  // Scheduled Dreaming
  useEffect(() => {
    const currentHour = new Date().getHours();
    if (currentHour === settings.dreamScheduleHour && !dreamMode && !isRecording) {
      setDreamMode(true);
    }
  }, [settings.dreamScheduleHour, isRecording, dreamMode]);

  useEffect(() => {
    // Add real event listeners for device motion and orientation
    const handleDeviceMotion = (event: DeviceMotionEvent) => {
      if (event.accelerationIncludingGravity) {
        setAccel(prev => {
          // Use a slight smoothing/lerp
          return {
            x: prev.x * 0.8 + (event.accelerationIncludingGravity!.x || 0) * 0.2,
            y: prev.y * 0.8 + (event.accelerationIncludingGravity!.y || 0) * 0.2,
            z: prev.z * 0.8 + (event.accelerationIncludingGravity!.z || 0) * 0.2
          };
        });
      }
      if (event.rotationRate) {
        setGyro(prev => {
           // We'll accumulate real rotation but since it's rotation rate, we might just use alpha beta gamma directly from DeviceOrientationEvent for absolute rotation
           // But let's just use rotation rate for a moment 
           return prev;
        });
      }
    };
    
    const handleDeviceOrientation = (event: DeviceOrientationEvent) => {
      const rawX = event.beta || 0;
      const rawY = event.gamma || 0;
      const rawZ = event.alpha || 0;
      
      // Cache raw variables
      rawGyroRef.current = { x: rawX, y: rawY, z: rawZ };

      // Subtract offsets for calibrated performance
      const calX = rawX - gyroOffsetRef.current.x;
      const calY = rawY - gyroOffsetRef.current.y;
      const calZ = rawZ - gyroOffsetRef.current.z;

      setGyro({
        x: calX,
        y: calY,
        z: calZ
      });
      if (event.alpha !== null) {
        // Keeps values in [0, 360) range cleanly
        setHeading(calZ >= 0 ? calZ % 360 : (calZ % 360) + 360);
      }
    };

    window.addEventListener('devicemotion', handleDeviceMotion, true);
    window.addEventListener('deviceorientation', handleDeviceOrientation, true);
    
    return () => {
      window.removeEventListener('devicemotion', handleDeviceMotion, true);
      window.removeEventListener('deviceorientation', handleDeviceOrientation, true);
    };
  }, []);

  useEffect(() => {
    const dataInterval = setInterval(() => {
      // ONLY simulate mic data and ping as those don't come from motion API
      setMicLeft(Math.random() * 100);
      setMicRight(Math.random() * 100);
      setPing(20 + Math.random() * 40 + (isRecording ? Math.random() * 100 : 0) + settings.simulationLag);
      
      const targetCpu = (isRecording || dreamMode) ? settings.cpuAllocationCore : 5;
      const targetGpu = (isRecording || dreamMode) ? settings.gpuAllocation : 2;
      const targetRam = (isRecording || dreamMode) ? settings.ramAllocation * 0.8 : settings.ramAllocation * 0.2;
      
      setCurrentCpu(prev => prev + (targetCpu - prev) * 0.2 + (Math.random() * 4 - 2));
      setCurrentGpu(prev => prev + (targetGpu - prev) * 0.2 + (Math.random() * 5 - 2.5));
      setCurrentRam(prev => prev + (targetRam - prev) * 0.1 + (Math.random() * 0.2 - 0.1));
      setCpuHistory(prev => [...prev.slice(1), Math.max(0, Math.min(100, targetCpu + (Math.random() * 4 - 2)))]);
    }, 100);
    return () => clearInterval(dataInterval);
  }, [isRecording, dreamMode, settings.simulationLag, settings.cpuAllocationCore, settings.gpuAllocation, settings.ramAllocation]);

  const currentSensors = useRef({ gyro, accel, micLeft, micRight, heading });
  useEffect(() => {
    currentSensors.current = { gyro, accel, micLeft, micRight, heading };
  }, [gyro, accel, micLeft, micRight, heading]);

  const memoriesRef = useRef<Memory[]>([]);
  useEffect(() => {
    memoriesRef.current = memories;
  }, [memories]);

  const handleResetAxis = () => {
    if (settings.sfxFile) {
      new Audio(settings.sfxFile).play().catch(e => console.error("Audio play failed:", e));
    }
    const currentRaw = rawGyroRef.current;
    if (currentRaw.x === 0 && currentRaw.y === 0 && currentRaw.z === 0) {
      // If flat PC simulator is used, calibrating brings lines perfectly flat to (0,0,0)
      setGyro({ x: 0, y: 0, z: 0 });
      setHeading(0);
    } else {
      setGyroOffset(currentRaw);
      gyroOffsetRef.current = currentRaw;
      setGyro({ x: 0, y: 0, z: 0 });
      setHeading(0);
    }
  };

  useEffect(() => {
    if (!isRecording && !dreamMode) return;

    const memoryInterval = setInterval(() => {
      const typeRand = Math.random();
      const type = dreamMode ? 'dream' : typeRand > settings.consciousThreshold ? 'conscious' : 'subconscious';
      
      const emotions = ['happy', 'sad', 'angry', 'neutral'] as const;
      let finalEmotion = emotions[Math.floor(Math.random() * emotions.length)];
      let finalSensors = currentSensors.current;
      let eventLog = isRecording ? "SENSORY DATA RECORDED AND ROUTED." : "BACKGROUND NEURAL ACTIVITY FLOW...";
      let baseImage: string | undefined = undefined;

      if (type === 'dream') {
         const lastConscious = memoriesRef.current.find(m => m.type === 'conscious');
         const lastSubconscious = memoriesRef.current.find(m => m.type === 'subconscious');
         if (lastConscious && lastSubconscious) {
            eventLog = `DREAM: Combines conscious [${lastConscious.hash}] & subconscious [${lastSubconscious.hash}] traces.`;
            finalEmotion = Math.random() > 0.5 ? lastConscious.emotion : lastSubconscious.emotion;
            finalSensors = {
               gyro: {
                  x: (lastConscious.sensors.gyro.x + lastSubconscious.sensors.gyro.x) / 2,
                  y: (lastConscious.sensors.gyro.y + lastSubconscious.sensors.gyro.y) / 2,
                  z: (lastConscious.sensors.gyro.z + lastSubconscious.sensors.gyro.z) / 2,
               },
               accel: {
                  x: (lastConscious.sensors.accel.x + lastSubconscious.sensors.accel.x) / 2,
                  y: (lastConscious.sensors.accel.y + lastSubconscious.sensors.accel.y) / 2,
                  z: (lastConscious.sensors.accel.z + lastSubconscious.sensors.accel.z) / 2,
               },
               micLeft: (lastConscious.sensors.micLeft + lastSubconscious.sensors.micLeft) / 2,
               micRight: (lastConscious.sensors.micRight + lastSubconscious.sensors.micRight) / 2,
               heading: (lastConscious.sensors.heading + lastSubconscious.sensors.heading) / 2,
            };
            baseImage = lastConscious.imageUrl || lastSubconscious.imageUrl;
         } else if (lastConscious) {
            eventLog = `DREAM: Anchors on conscious [${lastConscious.hash}] with simulated trace.`;
            finalEmotion = lastConscious.emotion;
            baseImage = lastConscious.imageUrl;
         } else {
            eventLog = "DREAM: Deep REM synthesis. No prior conscious traces found.";
         }
      }

      const newMemory: Memory = {
         id: crypto.randomUUID(),
         hash: '0x' + Math.floor(Math.random() * 65536).toString(16).toUpperCase().padStart(4, '0'),
         timestamp: Date.now(),
         type,
         sensors: finalSensors,
         eventLog,
         emotion: finalEmotion,
         storageSize: Math.floor(Math.random() * 2000) + 128
      };

      const snapshotUrl = captureCameraSnapshot(type);
      if (snapshotUrl) {
         newMemory.imageUrl = snapshotUrl;
      } else if (type === 'dream' && baseImage) {
         newMemory.imageUrl = baseImage;
      } else {
         newMemory.imageUrl = generateOfflineSensorySnapshot(type, finalSensors, finalEmotion);
      }
      
      setMemories(prev => {
         const updated = [newMemory, ...prev];
         let totalKb = updated.reduce((sum, m) => sum + (m.storageSize || 0), 0);
         while (updated.length > 0 && (totalKb / 1024) > settings.maxStoragePool) {
            const removed = updated.pop();
            if (removed) {
               totalKb -= removed.storageSize;
            }
         }
         return updated;
      });
    }, (1000 / settings.memoriesPerSecond)); 

    return () => clearInterval(memoryInterval);
  }, [isRecording, dreamMode, settings.consciousThreshold, settings.maxStoragePool, settings.memoriesPerSecond]);

   const handleToggleDream = () => {
    if (settings.sfxFile) {
      new Audio(settings.sfxFile).play().catch(e => console.error("Audio play failed:", e));
    }
    setDreamMode(!dreamMode);
    if (!dreamMode && isRecording) setIsRecording(false);
  };

  const handleToggleRecord = () => {
    if (settings.sfxFile) {
      new Audio(settings.sfxFile).play().catch(e => console.error("Audio play failed:", e));
    }
    setIsRecording(!isRecording);
  };

  const handleOpenSettings = () => {
    if (settings.sfxFile) {
      new Audio(settings.sfxFile).play().catch(e => console.error("Audio play failed:", e));
    }
    setShowSettings(true);
  };

  const handleOpenGallery = () => {
    if (settings.sfxFile) {
      new Audio(settings.sfxFile).play().catch(e => console.error("Audio play failed:", e));
    }
    setShowGallery(true);
  };

  const handleInjectMemory = () => {
    const sensorDataObj = { gyro, accel, micLeft, micRight, heading };
    const injected: Memory = {
       id: crypto.randomUUID(),
       hash: '0x' + Math.floor(Math.random() * 65536).toString(16).toUpperCase().padStart(4, '0'),
       timestamp: Date.now(),
       type: 'conscious',
       sensors: sensorDataObj,
       eventLog: "EXTERNAL MEMORY INJECTION PROTOCOL EXECUTED.",
       imageUrl: generateOfflineSensorySnapshot('conscious', sensorDataObj, 'neutral'),
       emotion: 'neutral',
       storageSize: 524
    };
    setMemories(prev => [injected, ...prev].slice(0, 50));
  };

  return (
    <div className="w-full h-screen overflow-hidden flex flex-col font-rajdhani selection:bg-cyber-red selection:text-white bg-[#030012] text-cyber-cyan relative">
      {settings.bgmFile && (
        <audio src={settings.bgmFile} autoPlay loop playsInline />
      )}
      <HexBackground speed={isRecording ? settings.processingSpeed : 0.5} lag={ping > 120 ? 0.2 : 0} cffRate={settings.cffRate} />
      <ConstellationBackground cffRate={settings.cffRate} />
      <AxisIndicator gyro={gyro} accel={accel} />

      {showGallery && <GalleryModal memories={memories} onClose={() => setShowGallery(false)} onInjectMemory={handleInjectMemory} />}
      {showSettings && <SettingsModal settings={settings} onUpdate={updateSetting} onClose={() => setShowSettings(false)} />}

      {/* Top Warning/Status Bar */}
      <div className="w-full border-b-[2px] border-dashed border-cyber-yellow/80 flex justify-between items-center px-4 py-[2px] z-10 bg-black/50 backdrop-blur-sm shadow-[0_2px_10px_rgba(243,230,0,0.1)]">
         <div className="flex gap-2">
           <span className="w-2 h-4 bg-cyber-yellow hidden sm:block"></span>
           <span className="text-cyber-yellow font-orbitron font-bold text-[10px] sm:text-xs tracking-widest mt-0.5">
             NEURAL POSITIONING SYSTEM HEADING: {heading.toFixed(1)}°
           </span>
         </div>
         <span className="text-cyber-yellow font-mono text-[10px] sm:text-xs tracking-widest">
           N {heading.toFixed(0)}° 6DOF ACTIVE  SYS_ID:01
         </span>
      </div>

      {/* Main Content Areas */}
      <div className="flex-1 relative z-10 w-full p-2 py-6 sm:p-6 lg:p-8 flex flex-col h-full pointer-events-none">
          
          <div className="flex flex-col lg:flex-row justify-between w-full flex-1 pointer-events-auto">
             {/* Left Panel */}
             <div className="flex flex-col w-full lg:w-1/3 pr-4">
                <div className="flex items-center gap-3 mb-2">
                  <svg className="w-11 h-11 text-red-500 drop-shadow-[0_0_10px_rgba(244,6,18,0.85)] shrink-0" viewBox="0 0 108 108" fill="none">
                    <path d="M 18,46 L 18,18 L 90,18 L 90,90 L 58,90 L 58,78 L 78,78 L 78,30 L 30,30 L 30,46 Z" fill="#F40612" />
                    <path d="M 18,54 L 18,90 L 50,90 L 50,78 L 30,78 L 30,54 Z" fill="#F40612" />
                    <path d="M 34,34 L 74,34 L 74,58 L 58,58 L 74,74 L 74,82 L 58,82 L 42,66 L 42,82 L 34,82 Z M 42,42 L 42,50 L 62,50 L 62,42 Z" fill="#F40612" fillRule="evenodd" />
                  </svg>
                  <div>
                    <div className="text-[#F40612] font-orbitron text-[10px] tracking-[0.35em] font-black drop-shadow-[0_0_5px_rgba(244,6,18,0.6)]">RELIC CORPORATION</div>
                    <h1 className="text-[#55ead4] font-orbitron text-3xl sm:text-4xl font-bold tracking-[0.15em] drop-shadow-[0_0_8px_rgba(85,234,212,0.8)] leading-none mt-1">AKOSHI</h1>
                  </div>
                </div>
                <div className="text-cyber-cyan/40 text-[9px] font-mono tracking-widest pl-1">SENSORY OPTICS // MEMORY CONSOLIDATION PROTOCOLS</div>
                <div className="mt-8 flex flex-col items-center">
                   
                   {/* Custom Gallery Component matching screenshot */}
                   <div className="flex flex-col items-center gap-3 cursor-pointer hover:bg-cyber-cyan/10 p-2 rounded transition ml-auto mr-12" onClick={() => setShowGallery(true)}>
                      <div className="text-cyber-cyan font-orbitron text-xs tracking-[0.2em]">GALLERY</div>
                      <div className="grid grid-cols-2 gap-1 w-12 h-12">
                         <div className="bg-cyber-cyan/40 border border-cyber-cyan/50"></div>
                         <div className="bg-cyber-cyan/60 border border-cyber-cyan"></div>
                         <div className="bg-cyber-cyan/20 border border-cyber-cyan/30"></div>
                         <div className="bg-cyber-cyan/50 border border-cyber-cyan/60"></div>
                      </div>
                   </div>

                   {/* Functional Memory Consolidation Monitor */}
                   <div className="mt-8 font-mono text-[11px] text-cyber-cyan/80 flex flex-col gap-1.5 self-center w-48">
                      <div className="flex justify-between w-full">
                         <span>STORAGE USAGE:</span>
                         <span className="text-cyber-yellow">
                            {Math.min(100, ((memories.reduce((sum, m) => sum + (m.storageSize || 0), 0) / 1024) / Math.max(1, settings.maxStoragePool) * 100)).toFixed(0)}%
                         </span>
                      </div>
                      <div className="w-full bg-[#05001a] border border-cyber-cyan/40 h-[6px] relative">
                         <div 
                            className="bg-cyber-cyan/80 h-full transition-all duration-300" 
                            style={{ 
                               width: `${Math.min(100, ((memories.reduce((sum, m) => sum + (m.storageSize || 0), 0) / 1024) / Math.max(1, settings.maxStoragePool) * 100))}%` 
                            }}
                         ></div>
                      </div>
                      <div className="text-[9px] opacity-60 text-right mt-1">
                         {(memories.reduce((sum, m) => sum + (m.storageSize || 0), 0) / 1024).toFixed(1)} / {settings.maxStoragePool} MB
                      </div>
                      
                      <div className="flex justify-between w-full mt-2">
                         <span>CONSOLIDATION:</span>
                         <span className="text-cyber-cyan">{Math.floor((memories.length > 0 ? (memories.filter(m => m.type === 'dream').length / memories.length) : 0) * 100)}%</span>
                      </div>
                   </div>
                   
                   {/* Conscious active processing bar */}
                   <div className="mt-6 flex flex-col gap-1 w-48 self-center">
                      <div className="text-cyber-cyan font-orbitron text-[11px] text-center tracking-widest">CONSCIOUS</div>
                      <div className="text-cyber-cyan font-orbitron text-[9px] text-center tracking-widest mt-4">ACTIVE</div>
                      <div className="text-cyber-cyan font-orbitron text-[9px] text-center tracking-widest border-t border-cyber-cyan/40 pt-1">PROCESSING</div>
                      <div className="w-full bg-[#05001a] border border-cyber-cyan/40 h-[6px] mt-1 relative">
                         <div className="bg-cyber-cyan h-full transition-all duration-300 shadow-[0_0_8px_rgba(85,234,212,0.6)]" style={{ width: `${Math.max(2, Math.min(100, (currentRam / settings.ramAllocation) * 100))}%` }}></div>
                      </div>
                      <div className="text-center font-mono text-[9px] text-cyber-cyan mt-1 border border-cyber-cyan/50 w-fit mx-auto px-4 py-0.5">{Math.floor(currentRam * 1024 * 0.72)} MB</div>
                   </div>
                </div>
             </div>

             {/* Center Panel (Neural Net + Gyro) */}
             <div className="flex flex-col w-full lg:w-1/3 items-center pt-2">
                <NeuralNet 
                   totalNodes={settings.matchGridToNeurons ? settings.neuralDensity : 256} 
                   activeNodes={Math.floor(settings.neuralDensity * (Math.max(0, currentCpu) / 100))} 
                />
                
                <div className="flex w-full justify-between mt-12 px-4 max-w-sm">
                   <div className="flex flex-col items-center">
                      <span className="font-orbitron tracking-widest text-[#55ead4] text-[10px] mb-3">GYROSCOPE DATA</span>
                      <div className="font-mono text-[11px] text-center flex flex-col gap-1.5 text-cyber-cyan/80">
                         <span>R: {gyro.x.toFixed(1)}°</span>
                         <span>P: {gyro.y.toFixed(1)}°</span>
                         <span>Y: {gyro.z.toFixed(1)}°</span>
                      </div>
                   </div>
                   <div className="flex flex-col items-center">
                      <span className="font-orbitron tracking-widest text-[#55ead4] text-[10px] mb-3">ACCELEROMETER DATA</span>
                      <div className="font-mono text-[11px] text-center flex flex-col gap-1.5 text-cyber-cyan/80">
                         <span>X: {accel.x.toFixed(3)}</span>
                         <span>Y: {accel.y.toFixed(3)}</span>
                         <span>Z: {accel.z.toFixed(3)}</span>
                      </div>
                   </div>
                </div>
             </div>

             {/* Right Panel */}
             <div className="flex flex-col w-full lg:w-1/3 items-end pr-4 pl-8 pt-10">
                
                <div className="flex flex-col items-center w-56">
                   <span className="font-orbitron text-cyber-cyan text-[11px] tracking-widest mb-1 text-center">RESOURCES</span>
                   <span className="font-mono text-[9px] text-cyber-cyan/50 mb-1 text-center">LG G7 ThinQ LM-G710VM</span>
                   <span className="font-mono text-[8px] text-cyber-cyan/40 mb-3 text-center tracking-widest">Snapdragon 845 | 4GB RAM | 1440x3120</span>
                   {/* Abstract Graph Simulation */}
                   <div className="w-full h-12 bg-transparent relative mb-2 flex items-center justify-center border-b border-cyber-cyan/20 pb-2">
                       
                       
                       
                       
                       
                       <svg className="absolute inset-0 w-full h-[80%] opacity-80 stroke-cyber-cyan stroke-[3px] fill-transparent" preserveAspectRatio="none" viewBox="0 0 100 100">
                          <polyline points={cpuHistory.map((val, i) => `${(i / (cpuHistory.length - 1)) * 100},${100 - val}`).join(' ')} />
                       </svg>
                   </div>
                   <div className="font-mono text-[10px] text-cyber-cyan/70 w-full flex justify-between mt-1">
                      <span>CPU:</span> <span className="text-cyber-cyan">{Math.max(0, Math.min(100, currentCpu)).toFixed(1)}%</span>
                   </div>
                   <div className="font-mono text-[10px] text-cyber-cyan/70 w-full flex justify-between mt-0.5">
                      <span>RAM:</span> <span className="text-cyber-cyan">{Math.max(0, currentRam).toFixed(2)} GB</span>
                   </div>
                   <div className="font-mono text-[10px] text-cyber-cyan/70 w-full flex justify-between mt-0.5">
                      <span>GPU ACCEL:</span> <span className="text-cyber-cyan">{Math.max(0, Math.min(100, currentGpu)).toFixed(1)}%</span>
                   </div>
                </div>
                
                {/* Echolocation/Camera Feed moved up here */}
                <div className="flex gap-2 mt-8 pointer-events-auto justify-end w-full max-w-[400px]">
                   {/* Left Feed */}
                   <div className="flex flex-col w-40 sm:w-48">
                      <div className="text-cyber-cyan/80 tracking-[0.2em] text-[10px] font-orbitron mb-1 text-center">
                        {settings.visualMode === 'echolocation' ? 'SONAR L' : settings.selectedCameraId === 'location' ? 'LOC L' : 'OPTICAL FEED 1'}
                      </div>
                      <div className="w-full aspect-video border border-cyber-cyan/30 bg-black/80 flex items-center justify-center p-[2px] relative overflow-hidden">
                         <div className="absolute top-0 right-0 w-8 h-8 border-t border-r border-cyber-cyan/50 z-20 m-1"></div>
                         <div className="absolute bottom-0 left-0 w-8 h-8 border-b border-l border-cyber-red/50 z-20 m-1"></div>
                         <CameraFeed settings={settings} gyro={gyro} accel={accel} micLeft={micLeft} micRight={micRight} dreamMode={dreamMode} memories={memories} />
                      </div>
                   </div>

                   {/* Right Feed (Stereoscopic) */}
                   <div className="flex flex-col w-40 sm:w-48">
                      <div className="text-cyber-cyan/80 tracking-[0.2em] text-[10px] font-orbitron mb-1 text-center">
                         {settings.visualMode === 'echolocation' ? 'SONAR R' : settings.selectedCamera2Id === 'location' ? 'LOC R' : 'OPTICAL FEED 2'}
                      </div>
                      <div className="w-full aspect-video border border-cyber-cyan/30 bg-black/80 flex items-center justify-center p-[2px] relative overflow-hidden group">
                         <div className="absolute top-0 left-0 w-8 h-8 border-t border-l border-cyber-cyan/50 z-20 m-1"></div>
                         <div className="absolute bottom-0 right-0 w-8 h-8 border-b border-r border-cyber-red/50 z-20 m-1"></div>
                         {(!settings.enableCamera2) ? (
                            <div className="absolute inset-0 flex flex-col items-center justify-center bg-[#050005] glitch-hardware z-10 p-2">
                               <div className="font-mono text-[8px] text-cyber-red/80 text-center tracking-widest pt-2">
                                 S-VISION<br/>OFFLINE
                               </div>
                               <button 
                                 onClick={() => updateSetting('enableCamera2', true)}
                                 className="mt-2 bg-cyber-red/10 border border-cyber-red/50 text-cyber-red text-[7px] px-2 py-1 font-orbitron hover:bg-cyber-red/30 transition-colors"
                               >
                                 [ ACTIVATE ]
                               </button>
                               <div className="absolute inset-0 bg-[repeating-linear-gradient(transparent,transparent_2px,rgba(255,0,0,0.1)_3px,transparent_4px)] pointer-events-none mix-blend-screen opacity-50" />
                            </div>
                         ) : (
                            <CameraFeed settings={{...settings, selectedCameraId: settings.selectedCamera2Id}} gyro={gyro} accel={accel} micLeft={micRight} micRight={micLeft} dreamMode={dreamMode} memories={memories} isFeed2={true} />
                         )}
                      </div>
                   </div>
                </div>

                <div className="mt-8 flex flex-col gap-1 w-48 mr-auto lg:mx-auto">
                   <div className="text-cyber-cyan/80 font-orbitron text-[11px] text-center tracking-widest relative">
                     {/* Floating quote brackets style */}
                     <span className="absolute -left-2 top-0">"</span>SUBCONSCIOUS<span className="absolute -right-2 top-0">"</span>
                   </div>
                   <div className="text-cyber-cyan/70 font-orbitron text-[9px] text-center tracking-widest mt-4">BACKGROUND</div>
                   <div className="text-cyber-cyan/70 font-orbitron text-[9px] text-center tracking-widest border-t border-cyber-cyan/20 pt-1">PROCESSING</div>
                   <div className="w-full bg-[#05001a] border border-cyber-cyan/30 h-[6px] mt-1 relative">
                      <div className="bg-cyber-cyan/50 h-full transition-all duration-300" style={{ width: `${Math.max(2, Math.min(100, currentGpu))}%` }}></div>
                   </div>
                   <div className="text-center font-mono text-[9px] text-cyber-cyan/70 mt-1 border border-cyber-cyan/40 w-fit mx-auto px-4 py-0.5">{Math.floor(currentRam * 1024 * 0.28)} MB</div>
                </div>

                <div className="mt-auto mb-16 lg:mb-4 lg:self-end self-center xl:mr-16">
                   <ControlPanel 
                     isRecording={isRecording} 
                     onToggleRecord={handleToggleRecord} 
                     dreamMode={dreamMode}
                     onToggleDream={handleToggleDream}
                     onOpenSettings={handleOpenSettings}
                     onOpenGallery={handleOpenGallery}
                     ping={ping}
                     onResetAxis={handleResetAxis}
                   />
                </div>
             </div>
          </div>

          {/* Bottom Feeds Row */}
          <div className="mt-auto w-full flex flex-col lg:flex-row gap-4 lg:gap-8 h-48 lg:h-56 pointer-events-auto">
             
             {/* Left Log Stream (Now Full Width) */}
             <div className="flex-1 flex flex-col w-full relative">
                <div className="text-cyber-red tracking-[0.2em] text-[10px] font-orbitron mb-1 flex items-center">
                  <span>LIVE OUTPUT</span>
                </div>
                <div className="w-full flex-1 border border-cyber-cyan/30 bg-[#020010]/80 backdrop-blur-sm p-4 font-mono text-[10px] text-cyber-cyan/80 overflow-y-auto custom-scrollbar flex flex-col-reverse shadow-[inset_0_0_20px_rgba(85,234,212,0.05)]">
                   {memories.length === 0 ? "AWAITING SENSORY INPUT..." : memories.map((mem) => (
                     <div key={mem.id} className="mb-3 flex flex-col gap-1 border-l-2 pl-2 border-cyber-cyan/30">
                        <div className="flex gap-2">
                          <span className="opacity-40 shrink-0">{new Date(mem.timestamp).toLocaleTimeString([], { hour12: false })}</span>
                          <span className={`${mem.type === 'dream' ? 'text-cyber-yellow' : mem.type === 'conscious' ? 'text-[#55ead4]' : 'text-[#55ead4]/60'} flex-1`}>
                            [{mem.type.toUpperCase()}] [{mem.hash || "0x0000"}] {mem.eventLog} 
                            <span className="ml-2 opacity-50">| EMOTION: {mem.emotion.toUpperCase()} | VOL: {mem.storageSize}KB</span>
                          </span>
                        </div>
                        {mem.imageUrl && (
                          <div className="mt-1 flex items-center gap-2 text-cyber-cyan/60">
                             <span>└─</span>
                             <div className={`relative h-12 w-12 border ${mem.type === 'dream' ? 'border-cyber-yellow/65' : 'border-cyber-cyan/50'} opacity-95 overflow-hidden bg-black/40`}>
                                {mem.type === 'subconscious' ? (
                                   // Subconscious memories only remember a certain part of an image
                                   <img 
                                     src={mem.imageUrl} 
                                     alt="Subconscious fragment" 
                                     className="absolute w-[250%] h-[250%] max-w-none object-cover" 
                                     style={{ top: '-40%', left: '-30%', filter: 'contrast(125%) brightness(110%) blur(0.5px)' }} 
                                   />
                                ) : mem.type === 'dream' ? (
                                   // Dream is a composite of conscious trace & subconscious shifts
                                   <>
                                     <img 
                                       src={mem.imageUrl} 
                                       alt="Dream backing" 
                                       className="absolute w-full h-full object-cover opacity-50 brightness-110 saturate-150" 
                                     />
                                     <img 
                                       src={mem.imageUrl} 
                                       alt="Dream shift overlay" 
                                       className="absolute w-[180%] h-[180%] max-w-none object-cover opacity-60 mix-blend-screen scale-75 rotate-12" 
                                       style={{ top: '-10%', left: '-10%', filter: 'hue-rotate(90deg)' }} 
                                     />
                                   </>
                                ) : (
                                   // Conscious memories remember the whole thing
                                   <img 
                                     src={mem.imageUrl} 
                                     alt="Conscious record" 
                                     className="w-full h-full object-cover" 
                                   />
                                )}
                             </div>
                             <span className="text-[8px] opacity-50">
                                {mem.type === 'subconscious' ? '[ SUBCONSCIOUS TRACE FRAGMENT ]' : mem.type === 'dream' ? '[ SURREAL DREAM COMPOSITE SYNTHESIS ]' : '[ FULL CONSCIOUS IMAGE RECORD ]'}
                             </span>
                          </div>
                        )}
                        <div className="text-[8px] opacity-40 ml-4">
                           SENSORS: HEADING {mem.sensors.heading.toFixed(0)}° | MIC-L {mem.sensors.micLeft.toFixed(0)} | MIC-R {mem.sensors.micRight.toFixed(0)}
                        </div>
                     </div>
                   ))}
                </div>
             </div>

          </div>
      </div>
    </div>
  );
}
